
from .Bjarne1358 import Bjarne1358


class Bjarne1765(Bjarne1358):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "IrhAh"
        
        
        
        self.c = "p3kop3ko"
        
        
        self.d = "xR4Y"
        
        
        
        
        self.g = "k3wL_83An5"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)