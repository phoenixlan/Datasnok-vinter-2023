
from .Bjarne121 import Bjarne121


class Bjarne417(Bjarne121):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "xbg"
        
        
        self.c = "IrhAh"
        
        
        self.d = "xbg"
        
        
        self.e = "p3kop3ko"
        
        
        
        self.g = "xbg"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)