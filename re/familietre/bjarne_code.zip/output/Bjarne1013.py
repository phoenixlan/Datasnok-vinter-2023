
from .Bjarne866 import Bjarne866


class Bjarne1013(Bjarne866):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "l3375P33k"
        
        
        
        
        self.e = "xbg"
        
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)