
from .Bjarne1169 import Bjarne1169


class Bjarne1476(Bjarne1169):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "k3wL_83An5"
        
        
        
        
        self.d = "k3wL_83An5"
        
        
        
        self.f = "xR4Y"
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)