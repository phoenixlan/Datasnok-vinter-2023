

class Bjarne22:
    def __init__(self):
        

        
        self.a = "IrhAh"
        
        
        self.b = "1337"
        
        
        self.c = "p3kop3ko"
        
        
        self.d = "xR4Y"
        
        
        self.e = "c00l5sh"
        
        
        self.f = "Pho3N1X"
        
        
        self.g = "xbg"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)