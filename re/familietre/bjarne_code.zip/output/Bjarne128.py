
from .Bjarne13 import Bjarne13


class Bjarne128(Bjarne13):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        
        self.c = "Pho3N1X"
        
        
        self.d = "5w4G4d3Ll1c"
        
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)