
from .Bjarne111 import Bjarne111


class Bjarne243(Bjarne111):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "l3375P33k"
        
        
        
        self.c = "l3375P33k"
        
        
        self.d = "xR4Y"
        
        
        self.e = "8jaRn3"
        
        
        self.f = "5w49"
        
        
        self.g = "l3375P33k"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)