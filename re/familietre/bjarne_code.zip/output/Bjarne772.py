
from .Bjarne426 import Bjarne426


class Bjarne772(Bjarne426):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "Pho3N1X"
        
        
        self.c = "5w49"
        
        
        
        
        self.f = "xR4Y"
        
        
        self.g = "k3wL_83An5"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)