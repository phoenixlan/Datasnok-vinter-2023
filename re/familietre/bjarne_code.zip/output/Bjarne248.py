
from .Bjarne21 import Bjarne21


class Bjarne248(Bjarne21):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "c00l5sh"
        
        
        self.b = "1337"
        
        
        self.c = "xbg"
        
        
        
        
        self.f = "1337"
        
        
        self.g = "8jaRn3"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)