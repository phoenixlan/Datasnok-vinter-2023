
from .Bjarne791 import Bjarne791


class Bjarne1260(Bjarne791):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "5w49"
        
        
        self.c = "l3375P33k"
        
        
        
        self.e = "5w4G4d3Ll1c"
        
        
        
        self.g = "IrhAh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)