
from .Bjarne393 import Bjarne393


class Bjarne1627(Bjarne393):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "p3kop3ko"
        
        
        
        self.d = "IrhAh"
        
        
        
        self.f = "8jaRn3"
        
        
        self.g = "1337"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)