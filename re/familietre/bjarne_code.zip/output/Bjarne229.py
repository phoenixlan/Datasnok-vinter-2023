
from .Bjarne60 import Bjarne60


class Bjarne229(Bjarne60):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "k3wL_83An5"
        
        
        self.b = "IrhAh"
        
        
        self.c = "5w49"
        
        
        self.d = "Pho3N1X"
        
        
        self.e = "Pho3N1X"
        
        
        
        self.g = "5w49"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)