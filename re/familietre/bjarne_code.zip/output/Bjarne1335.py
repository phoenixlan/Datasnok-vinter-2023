
from .Bjarne848 import Bjarne848


class Bjarne1335(Bjarne848):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "l3375P33k"
        
        
        self.c = "IrhAh"
        
        
        self.d = "k3wL_83An5"
        
        
        
        self.f = "k3wL_83An5"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)