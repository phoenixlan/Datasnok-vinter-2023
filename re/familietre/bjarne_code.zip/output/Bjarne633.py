
from .Bjarne107 import Bjarne107


class Bjarne633(Bjarne107):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "c00l5sh"
        
        
        self.b = "l3375P33k"
        
        
        self.c = "5w49"
        
        
        
        self.e = "k3wL_83An5"
        
        
        self.f = "Pho3N1X"
        
        
        self.g = "Pho3N1X"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)