
from .Bjarne108 import Bjarne108


class Bjarne595(Bjarne108):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "xR4Y"
        
        
        self.c = "l3375P33k"
        
        
        
        self.e = "5w49"
        
        
        self.f = "xbg"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)