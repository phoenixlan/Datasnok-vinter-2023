
from .Bjarne131 import Bjarne131


class Bjarne626(Bjarne131):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w49"
        
        
        
        self.c = "p3kop3ko"
        
        
        self.d = "xR4Y"
        
        
        self.e = "8jaRn3"
        
        
        
        self.g = "k3wL_83An5"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)