
from .Bjarne1017 import Bjarne1017


class Bjarne1380(Bjarne1017):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "p3kop3ko"
        
        
        self.b = "c00l5sh"
        
        
        self.c = "c00l5sh"
        
        
        self.d = "xbg"
        
        
        self.e = "xbg"
        
        
        self.f = "1337"
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)