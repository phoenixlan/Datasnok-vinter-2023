
from .Bjarne452 import Bjarne452


class Bjarne760(Bjarne452):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "c00l5sh"
        
        
        
        self.c = "xbg"
        
        
        self.d = "5w49"
        
        
        self.e = "xbg"
        
        
        self.f = "8jaRn3"
        
        
        self.g = "Pho3N1X"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)