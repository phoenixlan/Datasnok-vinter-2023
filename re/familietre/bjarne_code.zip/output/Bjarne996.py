
from .Bjarne877 import Bjarne877


class Bjarne996(Bjarne877):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xbg"
        
        
        self.b = "k3wL_83An5"
        
        
        self.c = "IrhAh"
        
        
        self.d = "IrhAh"
        
        
        self.e = "xbg"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)