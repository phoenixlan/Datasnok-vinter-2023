
from .Bjarne224 import Bjarne224


class Bjarne687(Bjarne224):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        self.b = "8jaRn3"
        
        
        self.c = "k3wL_83An5"
        
        
        
        self.e = "5w49"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)