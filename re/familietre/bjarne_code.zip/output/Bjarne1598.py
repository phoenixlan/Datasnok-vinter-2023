
from .Bjarne1381 import Bjarne1381


class Bjarne1598(Bjarne1381):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "p3kop3ko"
        
        
        self.b = "k3wL_83An5"
        
        
        self.c = "8jaRn3"
        
        
        self.d = "5w49"
        
        
        
        self.f = "5w4G4d3Ll1c"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)