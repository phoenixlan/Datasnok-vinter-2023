
from .Bjarne586 import Bjarne586


class Bjarne896(Bjarne586):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xR4Y"
        
        
        
        self.c = "5w49"
        
        
        
        
        self.f = "p3kop3ko"
        
        
        self.g = "Pho3N1X"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)