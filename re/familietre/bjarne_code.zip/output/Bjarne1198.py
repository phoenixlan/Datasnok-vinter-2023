
from .Bjarne422 import Bjarne422


class Bjarne1198(Bjarne422):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "IrhAh"
        
        
        self.b = "l3375P33k"
        
        
        
        self.d = "c00l5sh"
        
        
        self.e = "8jaRn3"
        
        
        self.f = "p3kop3ko"
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)