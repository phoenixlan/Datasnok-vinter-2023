
from .Bjarne1478 import Bjarne1478


class Bjarne1522(Bjarne1478):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        self.b = "Pho3N1X"
        
        
        self.c = "c00l5sh"
        
        
        self.d = "c00l5sh"
        
        
        self.e = "p3kop3ko"
        
        
        self.f = "8jaRn3"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)