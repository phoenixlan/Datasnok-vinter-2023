
from .Bjarne124 import Bjarne124


class Bjarne152(Bjarne124):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "p3kop3ko"
        
        
        self.d = "c00l5sh"
        
        
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)