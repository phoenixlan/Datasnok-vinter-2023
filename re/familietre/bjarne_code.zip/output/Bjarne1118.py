
from .Bjarne1051 import Bjarne1051


class Bjarne1118(Bjarne1051):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "8jaRn3"
        
        
        self.c = "8jaRn3"
        
        
        self.d = "5w4G4d3Ll1c"
        
        
        
        
        self.g = "5w49"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)