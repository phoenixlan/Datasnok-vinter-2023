
from .Bjarne1328 import Bjarne1328


class Bjarne1541(Bjarne1328):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "c00l5sh"
        
        
        self.b = "5w4G4d3Ll1c"
        
        
        
        self.d = "Pho3N1X"
        
        
        self.e = "xbg"
        
        
        self.f = "5w4G4d3Ll1c"
        
        
        self.g = "5w49"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)