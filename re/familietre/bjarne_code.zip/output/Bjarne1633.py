
from .Bjarne566 import Bjarne566


class Bjarne1633(Bjarne566):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "xR4Y"
        
        
        self.c = "k3wL_83An5"
        
        
        self.d = "xbg"
        
        
        
        self.f = "c00l5sh"
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)