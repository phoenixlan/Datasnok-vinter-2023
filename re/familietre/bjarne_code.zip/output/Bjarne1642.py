
from .Bjarne1154 import Bjarne1154


class Bjarne1642(Bjarne1154):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "xbg"
        
        
        self.c = "5w49"
        
        
        self.d = "xR4Y"
        
        
        self.e = "k3wL_83An5"
        
        
        self.f = "8jaRn3"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)