
from .Bjarne618 import Bjarne618


class Bjarne1761(Bjarne618):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "5w4G4d3Ll1c"
        
        
        self.c = "8jaRn3"
        
        
        self.d = "k3wL_83An5"
        
        
        
        self.f = "xbg"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)