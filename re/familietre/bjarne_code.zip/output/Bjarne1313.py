
from .Bjarne877 import Bjarne877


class Bjarne1313(Bjarne877):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "c00l5sh"
        
        
        
        self.c = "c00l5sh"
        
        
        self.d = "8jaRn3"
        
        
        
        self.f = "c00l5sh"
        
        
        self.g = "l3375P33k"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)