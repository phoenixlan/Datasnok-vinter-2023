
from .Bjarne1226 import Bjarne1226


class Bjarne1242(Bjarne1226):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xR4Y"
        
        
        
        
        
        self.e = "1337"
        
        
        
        self.g = "Pho3N1X"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)