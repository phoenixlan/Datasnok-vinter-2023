
from .Bjarne1394 import Bjarne1394


class Bjarne1826(Bjarne1394):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w4G4d3Ll1c"
        
        
        self.b = "5w49"
        
        
        
        self.d = "IrhAh"
        
        
        
        self.f = "1337"
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)