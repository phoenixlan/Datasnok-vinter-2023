
from .Bjarne107 import Bjarne107


class Bjarne255(Bjarne107):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "c00l5sh"
        
        
        
        self.d = "l3375P33k"
        
        
        self.e = "IrhAh"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)