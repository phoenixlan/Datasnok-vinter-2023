
from .Bjarne26 import Bjarne26


class Bjarne443(Bjarne26):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "p3kop3ko"
        
        
        self.b = "Pho3N1X"
        
        
        self.c = "l3375P33k"
        
        
        self.d = "xR4Y"
        
        
        self.e = "l3375P33k"
        
        
        self.f = "c00l5sh"
        
        
        self.g = "5w49"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)