
from .Bjarne65 import Bjarne65


class Bjarne184(Bjarne65):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xR4Y"
        
        
        self.b = "k3wL_83An5"
        
        
        self.c = "xbg"
        
        
        
        self.e = "5w49"
        
        
        self.f = "5w4G4d3Ll1c"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)