

class Bjarne42:
    def __init__(self):
        

        
        self.a = "1337"
        
        
        self.b = "IrhAh"
        
        
        self.c = "Pho3N1X"
        
        
        self.d = "Pho3N1X"
        
        
        self.e = "IrhAh"
        
        
        self.f = "IrhAh"
        
        
        self.g = "Pho3N1X"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)