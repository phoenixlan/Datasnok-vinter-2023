
from .Bjarne1220 import Bjarne1220


class Bjarne1402(Bjarne1220):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xR4Y"
        
        
        self.b = "k3wL_83An5"
        
        
        self.c = "Pho3N1X"
        
        
        
        
        self.f = "p3kop3ko"
        
        
        self.g = "IrhAh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)