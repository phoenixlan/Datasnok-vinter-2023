

class Bjarne95:
    def __init__(self):
        

        
        self.a = "5w4G4d3Ll1c"
        
        
        self.b = "k3wL_83An5"
        
        
        self.c = "k3wL_83An5"
        
        
        self.d = "5w49"
        
        
        self.e = "1337"
        
        
        self.f = "c00l5sh"
        
        
        self.g = "k3wL_83An5"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)