
from .Bjarne3 import Bjarne3


class Bjarne530(Bjarne3):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        self.b = "l3375P33k"
        
        
        self.c = "1337"
        
        
        self.d = "5w4G4d3Ll1c"
        
        
        
        
        self.g = "IrhAh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)