
from .Bjarne1220 import Bjarne1220


class Bjarne1917(Bjarne1220):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w4G4d3Ll1c"
        
        
        self.b = "8jaRn3"
        
        
        self.c = "1337"
        
        
        
        self.e = "IrhAh"
        
        
        self.f = "1337"
        
        
        self.g = "5w49"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)