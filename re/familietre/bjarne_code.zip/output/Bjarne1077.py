
from .Bjarne1040 import Bjarne1040


class Bjarne1077(Bjarne1040):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "IrhAh"
        
        
        
        self.c = "p3kop3ko"
        
        
        
        self.e = "1337"
        
        
        self.f = "Pho3N1X"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)