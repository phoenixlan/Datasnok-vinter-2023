
from .Bjarne933 import Bjarne933


class Bjarne1581(Bjarne933):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "k3wL_83An5"
        
        
        self.b = "IrhAh"
        
        
        self.c = "xR4Y"
        
        
        self.d = "8jaRn3"
        
        
        
        self.f = "c00l5sh"
        
        
        self.g = "IrhAh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)