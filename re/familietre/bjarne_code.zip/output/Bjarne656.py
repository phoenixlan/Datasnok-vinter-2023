
from .Bjarne289 import Bjarne289


class Bjarne656(Bjarne289):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "Pho3N1X"
        
        
        self.d = "IrhAh"
        
        
        self.e = "5w49"
        
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)