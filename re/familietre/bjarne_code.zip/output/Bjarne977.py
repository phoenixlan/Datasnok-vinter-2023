
from .Bjarne556 import Bjarne556


class Bjarne977(Bjarne556):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "8jaRn3"
        
        
        self.b = "IrhAh"
        
        
        self.c = "c00l5sh"
        
        
        self.d = "5w4G4d3Ll1c"
        
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)