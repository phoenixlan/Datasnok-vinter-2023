
from .Bjarne343 import Bjarne343


class Bjarne853(Bjarne343):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "5w4G4d3Ll1c"
        
        
        self.c = "1337"
        
        
        self.d = "5w49"
        
        
        self.e = "xR4Y"
        
        
        
        self.g = "k3wL_83An5"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)