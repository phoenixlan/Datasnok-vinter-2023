
from .Bjarne568 import Bjarne568


class Bjarne570(Bjarne568):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "1337"
        
        
        self.b = "Pho3N1X"
        
        
        self.c = "8jaRn3"
        
        
        self.d = "k3wL_83An5"
        
        
        self.e = "IrhAh"
        
        
        self.f = "8jaRn3"
        
        
        self.g = "8jaRn3"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)