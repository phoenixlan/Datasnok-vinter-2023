
from .Bjarne515 import Bjarne515


class Bjarne544(Bjarne515):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "5w4G4d3Ll1c"
        
        
        self.c = "xR4Y"
        
        
        self.d = "5w4G4d3Ll1c"
        
        
        self.e = "IrhAh"
        
        
        self.f = "IrhAh"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)