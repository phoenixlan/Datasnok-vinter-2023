
from .Bjarne412 import Bjarne412


class Bjarne872(Bjarne412):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "8jaRn3"
        
        
        self.b = "k3wL_83An5"
        
        
        self.c = "IrhAh"
        
        
        self.d = "c00l5sh"
        
        
        
        self.f = "k3wL_83An5"
        
        
        self.g = "8jaRn3"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)