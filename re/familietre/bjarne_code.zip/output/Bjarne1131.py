
from .Bjarne151 import Bjarne151


class Bjarne1131(Bjarne151):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        self.b = "8jaRn3"
        
        
        self.c = "xbg"
        
        
        self.d = "c00l5sh"
        
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)