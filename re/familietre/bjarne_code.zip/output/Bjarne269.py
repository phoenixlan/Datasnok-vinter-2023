
from .Bjarne162 import Bjarne162


class Bjarne269(Bjarne162):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "k3wL_83An5"
        
        
        self.b = "5w49"
        
        
        self.c = "xbg"
        
        
        
        
        self.f = "c00l5sh"
        
        
        self.g = "k3wL_83An5"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)