
from .Bjarne144 import Bjarne144


class Bjarne208(Bjarne144):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "1337"
        
        
        self.b = "IrhAh"
        
        
        self.c = "1337"
        
        
        self.d = "p3kop3ko"
        
        
        
        self.f = "xbg"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)