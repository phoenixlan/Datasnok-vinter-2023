
from .Bjarne426 import Bjarne426


class Bjarne1220(Bjarne426):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "8jaRn3"
        
        
        self.b = "5w49"
        
        
        self.c = "l3375P33k"
        
        
        self.d = "xR4Y"
        
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)