
from .Bjarne1447 import Bjarne1447


class Bjarne1605(Bjarne1447):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xR4Y"
        
        
        self.b = "l3375P33k"
        
        
        
        self.d = "Pho3N1X"
        
        
        self.e = "xR4Y"
        
        
        self.f = "5w49"
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)