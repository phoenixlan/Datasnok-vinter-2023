
from .Bjarne819 import Bjarne819


class Bjarne1150(Bjarne819):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "xR4Y"
        
        
        self.d = "5w49"
        
        
        self.e = "c00l5sh"
        
        
        self.f = "c00l5sh"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)