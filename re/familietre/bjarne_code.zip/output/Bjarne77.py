

class Bjarne77:
    def __init__(self):
        

        
        self.a = "c00l5sh"
        
        
        self.b = "k3wL_83An5"
        
        
        self.c = "1337"
        
        
        self.d = "xbg"
        
        
        self.e = "xR4Y"
        
        
        self.f = "xbg"
        
        
        self.g = "1337"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)