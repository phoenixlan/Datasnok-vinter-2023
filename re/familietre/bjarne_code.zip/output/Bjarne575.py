
from .Bjarne482 import Bjarne482


class Bjarne575(Bjarne482):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "IrhAh"
        
        
        self.c = "Pho3N1X"
        
        
        self.d = "l3375P33k"
        
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)