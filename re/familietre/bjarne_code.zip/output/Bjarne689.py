
from .Bjarne588 import Bjarne588


class Bjarne689(Bjarne588):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "5w4G4d3Ll1c"
        
        
        self.c = "p3kop3ko"
        
        
        self.d = "p3kop3ko"
        
        
        self.e = "Pho3N1X"
        
        
        self.f = "1337"
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)