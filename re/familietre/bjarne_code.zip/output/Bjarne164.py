
from .Bjarne103 import Bjarne103


class Bjarne164(Bjarne103):
    def __init__(self):
        

        
        self.a = "5w49"
        
        
        
        self.c = "IrhAh"
        
        
        self.d = "l3375P33k"
        
        
        self.e = "8jaRn3"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)