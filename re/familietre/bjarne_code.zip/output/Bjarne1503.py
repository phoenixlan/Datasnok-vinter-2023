
from .Bjarne1079 import Bjarne1079


class Bjarne1503(Bjarne1079):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "1337"
        
        
        self.c = "IrhAh"
        
        
        self.d = "c00l5sh"
        
        
        
        self.f = "Pho3N1X"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)