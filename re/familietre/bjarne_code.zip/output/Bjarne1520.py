
from .Bjarne900 import Bjarne900


class Bjarne1520(Bjarne900):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "1337"
        
        
        self.b = "5w49"
        
        
        
        
        self.e = "5w4G4d3Ll1c"
        
        
        self.f = "c00l5sh"
        
        
        self.g = "8jaRn3"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)