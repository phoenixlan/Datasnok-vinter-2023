
from .Bjarne294 import Bjarne294


class Bjarne971(Bjarne294):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "c00l5sh"
        
        
        self.b = "1337"
        
        
        self.c = "8jaRn3"
        
        
        self.d = "Pho3N1X"
        
        
        self.e = "5w4G4d3Ll1c"
        
        
        self.f = "8jaRn3"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)