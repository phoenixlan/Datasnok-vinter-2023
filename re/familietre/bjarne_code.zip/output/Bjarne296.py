
from .Bjarne178 import Bjarne178


class Bjarne296(Bjarne178):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "c00l5sh"
        
        
        self.b = "p3kop3ko"
        
        
        
        self.d = "xR4Y"
        
        
        self.e = "p3kop3ko"
        
        
        self.f = "8jaRn3"
        
        
        self.g = "IrhAh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)