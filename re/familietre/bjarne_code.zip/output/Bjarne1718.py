
from .Bjarne280 import Bjarne280


class Bjarne1718(Bjarne280):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w49"
        
        
        
        self.c = "p3kop3ko"
        
        
        self.d = "8jaRn3"
        
        
        self.e = "c00l5sh"
        
        
        self.f = "8jaRn3"
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)