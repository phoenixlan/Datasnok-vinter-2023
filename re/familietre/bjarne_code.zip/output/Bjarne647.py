
from .Bjarne340 import Bjarne340


class Bjarne647(Bjarne340):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        self.b = "Pho3N1X"
        
        
        self.c = "l3375P33k"
        
        
        self.d = "IrhAh"
        
        
        self.e = "8jaRn3"
        
        
        self.f = "8jaRn3"
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)