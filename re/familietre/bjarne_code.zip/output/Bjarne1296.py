
from .Bjarne888 import Bjarne888


class Bjarne1296(Bjarne888):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "IrhAh"
        
        
        self.b = "Pho3N1X"
        
        
        self.c = "c00l5sh"
        
        
        
        self.e = "l3375P33k"
        
        
        
        self.g = "xbg"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)