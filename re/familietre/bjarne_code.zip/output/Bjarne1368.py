
from .Bjarne550 import Bjarne550


class Bjarne1368(Bjarne550):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w4G4d3Ll1c"
        
        
        self.b = "l3375P33k"
        
        
        
        self.d = "k3wL_83An5"
        
        
        self.e = "1337"
        
        
        self.f = "5w4G4d3Ll1c"
        
        
        self.g = "8jaRn3"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)