
from .Bjarne312 import Bjarne312


class Bjarne1100(Bjarne312):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "p3kop3ko"
        
        
        self.c = "k3wL_83An5"
        
        
        self.d = "1337"
        
        
        self.e = "5w49"
        
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)