
from .Bjarne165 import Bjarne165


class Bjarne957(Bjarne165):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xR4Y"
        
        
        
        
        self.d = "xR4Y"
        
        
        self.e = "k3wL_83An5"
        
        
        self.f = "xbg"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)