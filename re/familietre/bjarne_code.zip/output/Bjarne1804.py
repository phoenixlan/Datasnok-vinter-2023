
from .Bjarne1746 import Bjarne1746


class Bjarne1804(Bjarne1746):
    def __init__(self):
        

        
        self.a = "c00l5sh"
        
        
        self.b = "Pho3N1X"
        
        
        self.c = "l3375P33k"
        
        
        self.d = "IrhAh"
        
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)