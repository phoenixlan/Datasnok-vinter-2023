
from .Bjarne1104 import Bjarne1104


class Bjarne1919(Bjarne1104):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "l3375P33k"
        
        
        self.b = "Pho3N1X"
        
        
        self.c = "k3wL_83An5"
        
        
        self.d = "xbg"
        
        
        self.e = "1337"
        
        
        self.f = "l3375P33k"
        
        
        self.g = "xbg"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)