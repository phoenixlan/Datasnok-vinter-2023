
from .Bjarne449 import Bjarne449


class Bjarne1343(Bjarne449):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "p3kop3ko"
        
        
        
        
        self.d = "1337"
        
        
        
        self.f = "IrhAh"
        
        
        self.g = "xR4Y"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)