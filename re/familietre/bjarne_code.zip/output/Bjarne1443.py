
from .Bjarne322 import Bjarne322


class Bjarne1443(Bjarne322):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "xbg"
        
        
        self.c = "l3375P33k"
        
        
        self.d = "8jaRn3"
        
        
        
        self.f = "p3kop3ko"
        
        
        self.g = "1337"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)