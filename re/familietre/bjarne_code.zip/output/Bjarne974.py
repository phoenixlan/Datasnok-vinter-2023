
from .Bjarne105 import Bjarne105


class Bjarne974(Bjarne105):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xR4Y"
        
        
        self.b = "p3kop3ko"
        
        
        self.c = "p3kop3ko"
        
        
        self.d = "Pho3N1X"
        
        
        self.e = "5w4G4d3Ll1c"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)