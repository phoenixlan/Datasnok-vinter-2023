
from .Bjarne411 import Bjarne411


class Bjarne1247(Bjarne411):
    def __init__(self):
        

        
        self.a = "p3kop3ko"
        
        
        self.b = "8jaRn3"
        
        
        
        
        
        
        self.g = "IrhAh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)