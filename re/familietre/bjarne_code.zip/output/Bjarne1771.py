
from .Bjarne799 import Bjarne799


class Bjarne1771(Bjarne799):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "k3wL_83An5"
        
        
        
        self.c = "5w4G4d3Ll1c"
        
        
        
        self.e = "5w49"
        
        
        
        self.g = "p3kop3ko"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)