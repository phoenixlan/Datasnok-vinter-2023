
from .Bjarne1454 import Bjarne1454


class Bjarne1575(Bjarne1454):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "8jaRn3"
        
        
        self.b = "k3wL_83An5"
        
        
        self.c = "xR4Y"
        
        
        
        self.e = "l3375P33k"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)