
from .Bjarne1509 import Bjarne1509


class Bjarne1778(Bjarne1509):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "c00l5sh"
        
        
        self.c = "xR4Y"
        
        
        
        
        self.f = "5w49"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)