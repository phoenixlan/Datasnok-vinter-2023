
from .Bjarne120 import Bjarne120


class Bjarne282(Bjarne120):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "c00l5sh"
        
        
        self.c = "xbg"
        
        
        self.d = "xbg"
        
        
        
        self.f = "8jaRn3"
        
        
        self.g = "8jaRn3"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)