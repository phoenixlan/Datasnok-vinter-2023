
from .Bjarne470 import Bjarne470


class Bjarne1252(Bjarne470):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "l3375P33k"
        
        
        self.c = "1337"
        
        
        self.d = "5w4G4d3Ll1c"
        
        
        self.e = "8jaRn3"
        
        
        self.f = "8jaRn3"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)