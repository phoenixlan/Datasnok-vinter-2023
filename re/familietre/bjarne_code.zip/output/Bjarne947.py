
from .Bjarne71 import Bjarne71


class Bjarne947(Bjarne71):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "8jaRn3"
        
        
        self.d = "1337"
        
        
        self.e = "k3wL_83An5"
        
        
        self.f = "1337"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)