
from .Bjarne294 import Bjarne294


class Bjarne343(Bjarne294):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        
        self.c = "8jaRn3"
        
        
        
        self.e = "xbg"
        
        
        self.f = "p3kop3ko"
        
        
        self.g = "1337"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)