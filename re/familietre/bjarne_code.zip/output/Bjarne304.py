
from .Bjarne44 import Bjarne44


class Bjarne304(Bjarne44):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "Pho3N1X"
        
        
        self.c = "8jaRn3"
        
        
        
        self.e = "Pho3N1X"
        
        
        
        self.g = "8jaRn3"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)