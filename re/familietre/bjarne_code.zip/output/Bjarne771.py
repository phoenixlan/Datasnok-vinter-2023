
from .Bjarne670 import Bjarne670


class Bjarne771(Bjarne670):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "IrhAh"
        
        
        self.d = "p3kop3ko"
        
        
        self.e = "xR4Y"
        
        
        self.f = "p3kop3ko"
        
        
        self.g = "5w49"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)