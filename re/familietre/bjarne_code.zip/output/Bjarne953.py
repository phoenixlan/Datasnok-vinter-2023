
from .Bjarne473 import Bjarne473


class Bjarne953(Bjarne473):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "p3kop3ko"
        
        
        
        self.d = "l3375P33k"
        
        
        self.e = "c00l5sh"
        
        
        self.f = "1337"
        
        
        self.g = "xR4Y"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)