
from .Bjarne733 import Bjarne733


class Bjarne1457(Bjarne733):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "c00l5sh"
        
        
        self.c = "c00l5sh"
        
        
        self.d = "k3wL_83An5"
        
        
        self.e = "k3wL_83An5"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)