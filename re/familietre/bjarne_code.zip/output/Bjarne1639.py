
from .Bjarne501 import Bjarne501


class Bjarne1639(Bjarne501):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "k3wL_83An5"
        
        
        
        self.c = "5w4G4d3Ll1c"
        
        
        self.d = "IrhAh"
        
        
        
        self.f = "k3wL_83An5"
        
        
        self.g = "xbg"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)