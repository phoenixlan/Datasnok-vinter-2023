
from .Bjarne1038 import Bjarne1038


class Bjarne1169(Bjarne1038):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "IrhAh"
        
        
        
        self.d = "IrhAh"
        
        
        self.e = "p3kop3ko"
        
        
        self.f = "l3375P33k"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)