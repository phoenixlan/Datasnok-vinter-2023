
from .Bjarne160 import Bjarne160


class Bjarne937(Bjarne160):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "p3kop3ko"
        
        
        self.b = "xbg"
        
        
        
        
        self.e = "Pho3N1X"
        
        
        self.f = "l3375P33k"
        
        
        self.g = "8jaRn3"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)