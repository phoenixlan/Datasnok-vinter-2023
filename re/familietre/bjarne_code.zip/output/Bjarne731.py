
from .Bjarne11 import Bjarne11


class Bjarne731(Bjarne11):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "8jaRn3"
        
        
        self.c = "k3wL_83An5"
        
        
        self.d = "IrhAh"
        
        
        self.e = "Pho3N1X"
        
        
        self.f = "xbg"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)