
from .Bjarne255 import Bjarne255


class Bjarne438(Bjarne255):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "IrhAh"
        
        
        self.b = "p3kop3ko"
        
        
        self.c = "8jaRn3"
        
        
        
        self.e = "c00l5sh"
        
        
        self.f = "IrhAh"
        
        
        self.g = "xR4Y"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)