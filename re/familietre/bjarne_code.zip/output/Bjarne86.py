

class Bjarne86:
    def __init__(self):
        

        
        self.a = "p3kop3ko"
        
        
        self.b = "c00l5sh"
        
        
        self.c = "5w4G4d3Ll1c"
        
        
        self.d = "xR4Y"
        
        
        self.e = "xR4Y"
        
        
        self.f = "IrhAh"
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)