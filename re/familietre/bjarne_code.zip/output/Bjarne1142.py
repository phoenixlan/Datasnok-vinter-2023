
from .Bjarne598 import Bjarne598


class Bjarne1142(Bjarne598):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w4G4d3Ll1c"
        
        
        self.b = "l3375P33k"
        
        
        self.c = "5w49"
        
        
        self.d = "xR4Y"
        
        
        self.e = "5w49"
        
        
        self.f = "p3kop3ko"
        
        
        self.g = "l3375P33k"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)