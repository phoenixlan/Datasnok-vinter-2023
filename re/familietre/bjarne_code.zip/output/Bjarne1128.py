
from .Bjarne99 import Bjarne99


class Bjarne1128(Bjarne99):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "8jaRn3"
        
        
        self.b = "Pho3N1X"
        
        
        self.c = "1337"
        
        
        self.d = "xR4Y"
        
        
        self.e = "p3kop3ko"
        
        
        
        self.g = "Pho3N1X"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)