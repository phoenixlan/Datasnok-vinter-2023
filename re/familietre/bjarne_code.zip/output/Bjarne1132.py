
from .Bjarne666 import Bjarne666


class Bjarne1132(Bjarne666):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xbg"
        
        
        self.b = "xR4Y"
        
        
        self.c = "c00l5sh"
        
        
        self.d = "xR4Y"
        
        
        self.e = "xbg"
        
        
        self.f = "8jaRn3"
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)