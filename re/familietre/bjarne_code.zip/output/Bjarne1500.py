
from .Bjarne925 import Bjarne925


class Bjarne1500(Bjarne925):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w49"
        
        
        
        self.c = "xbg"
        
        
        self.d = "xbg"
        
        
        self.e = "5w4G4d3Ll1c"
        
        
        self.f = "l3375P33k"
        
        
        self.g = "k3wL_83An5"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)