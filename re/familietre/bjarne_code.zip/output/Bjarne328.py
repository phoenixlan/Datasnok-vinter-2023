
from .Bjarne36 import Bjarne36


class Bjarne328(Bjarne36):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "p3kop3ko"
        
        
        self.b = "IrhAh"
        
        
        self.c = "IrhAh"
        
        
        self.d = "IrhAh"
        
        
        self.e = "1337"
        
        
        
        self.g = "5w49"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)