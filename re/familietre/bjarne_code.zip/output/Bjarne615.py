
from .Bjarne472 import Bjarne472


class Bjarne615(Bjarne472):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "l3375P33k"
        
        
        
        self.e = "xR4Y"
        
        
        self.f = "l3375P33k"
        
        
        self.g = "5w49"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)