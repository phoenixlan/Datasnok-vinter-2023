
from .Bjarne404 import Bjarne404


class Bjarne1752(Bjarne404):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "1337"
        
        
        
        
        
        self.e = "xbg"
        
        
        
        self.g = "5w49"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)