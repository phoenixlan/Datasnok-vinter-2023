
from .Bjarne224 import Bjarne224


class Bjarne1384(Bjarne224):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "1337"
        
        
        self.b = "xbg"
        
        
        self.c = "p3kop3ko"
        
        
        
        self.e = "8jaRn3"
        
        
        self.f = "IrhAh"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)