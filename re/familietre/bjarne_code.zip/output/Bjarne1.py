

class Bjarne1:
    def __init__(self):
        

        
        self.a = "IrhAh"
        
        
        self.b = "5w49"
        
        
        self.c = "1337"
        
        
        self.d = "xR4Y"
        
        
        self.e = "xbg"
        
        
        self.f = "5w49"
        
        
        self.g = "p3kop3ko"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)