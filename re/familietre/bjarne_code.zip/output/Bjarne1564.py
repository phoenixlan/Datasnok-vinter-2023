
from .Bjarne392 import Bjarne392


class Bjarne1564(Bjarne392):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w49"
        
        
        self.b = "xbg"
        
        
        
        self.d = "1337"
        
        
        self.e = "5w49"
        
        
        self.f = "p3kop3ko"
        
        
        self.g = "p3kop3ko"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)