
from .Bjarne23 import Bjarne23


class Bjarne240(Bjarne23):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "8jaRn3"
        
        
        self.b = "p3kop3ko"
        
        
        self.c = "l3375P33k"
        
        
        self.d = "k3wL_83An5"
        
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)