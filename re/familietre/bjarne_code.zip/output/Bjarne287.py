
from .Bjarne35 import Bjarne35


class Bjarne287(Bjarne35):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "p3kop3ko"
        
        
        self.c = "5w49"
        
        
        
        self.e = "1337"
        
        
        self.f = "k3wL_83An5"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)