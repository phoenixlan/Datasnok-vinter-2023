
from .Bjarne369 import Bjarne369


class Bjarne707(Bjarne369):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "5w49"
        
        
        
        
        self.f = "Pho3N1X"
        
        
        self.g = "1337"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)