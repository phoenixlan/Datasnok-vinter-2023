
from .Bjarne730 import Bjarne730


class Bjarne1994(Bjarne730):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "IrhAh"
        
        
        self.b = "5w49"
        
        
        
        
        self.e = "k3wL_83An5"
        
        
        
        self.g = "Pho3N1X"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)