
from .Bjarne1561 import Bjarne1561


class Bjarne1809(Bjarne1561):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w49"
        
        
        
        self.c = "l3375P33k"
        
        
        
        self.e = "c00l5sh"
        
        
        self.f = "c00l5sh"
        
        
        self.g = "1337"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)