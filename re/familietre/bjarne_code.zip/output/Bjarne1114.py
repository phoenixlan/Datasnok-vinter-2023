
from .Bjarne201 import Bjarne201


class Bjarne1114(Bjarne201):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        self.b = "IrhAh"
        
        
        self.c = "c00l5sh"
        
        
        self.d = "xbg"
        
        
        self.e = "p3kop3ko"
        
        
        self.f = "IrhAh"
        
        
        self.g = "p3kop3ko"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)