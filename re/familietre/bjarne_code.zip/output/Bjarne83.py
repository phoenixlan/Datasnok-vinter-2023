

class Bjarne83:
    def __init__(self):
        

        
        self.a = "5w4G4d3Ll1c"
        
        
        self.b = "5w49"
        
        
        self.c = "k3wL_83An5"
        
        
        self.d = "5w49"
        
        
        self.e = "xbg"
        
        
        self.f = "5w49"
        
        
        self.g = "xR4Y"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)