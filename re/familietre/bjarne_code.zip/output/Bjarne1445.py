
from .Bjarne325 import Bjarne325


class Bjarne1445(Bjarne325):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "1337"
        
        
        self.b = "8jaRn3"
        
        
        self.c = "p3kop3ko"
        
        
        self.d = "5w4G4d3Ll1c"
        
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)