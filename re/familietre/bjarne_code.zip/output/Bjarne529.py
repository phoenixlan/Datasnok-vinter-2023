
from .Bjarne469 import Bjarne469


class Bjarne529(Bjarne469):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "5w4G4d3Ll1c"
        
        
        
        self.d = "5w49"
        
        
        self.e = "5w4G4d3Ll1c"
        
        
        
        self.g = "IrhAh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)