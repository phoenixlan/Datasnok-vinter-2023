
from .Bjarne364 import Bjarne364


class Bjarne1148(Bjarne364):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "xbg"
        
        
        
        self.d = "c00l5sh"
        
        
        
        self.f = "l3375P33k"
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)