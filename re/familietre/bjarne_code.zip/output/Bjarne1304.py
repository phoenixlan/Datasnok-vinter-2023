
from .Bjarne769 import Bjarne769


class Bjarne1304(Bjarne769):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "IrhAh"
        
        
        self.b = "IrhAh"
        
        
        
        
        self.e = "p3kop3ko"
        
        
        self.f = "Pho3N1X"
        
        
        self.g = "p3kop3ko"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)