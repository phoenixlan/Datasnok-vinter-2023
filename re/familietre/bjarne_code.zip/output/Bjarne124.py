
from .Bjarne88 import Bjarne88


class Bjarne124(Bjarne88):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "8jaRn3"
        
        
        self.b = "1337"
        
        
        
        self.d = "p3kop3ko"
        
        
        self.e = "5w49"
        
        
        self.f = "c00l5sh"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)