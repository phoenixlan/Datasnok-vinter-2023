
from .Bjarne1685 import Bjarne1685


class Bjarne1735(Bjarne1685):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "xbg"
        
        
        
        
        
        self.f = "p3kop3ko"
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)