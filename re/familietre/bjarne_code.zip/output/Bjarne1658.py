
from .Bjarne454 import Bjarne454


class Bjarne1658(Bjarne454):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "xR4Y"
        
        
        self.c = "5w4G4d3Ll1c"
        
        
        self.d = "8jaRn3"
        
        
        self.e = "5w4G4d3Ll1c"
        
        
        self.f = "Pho3N1X"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)