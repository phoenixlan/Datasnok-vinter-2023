
from .Bjarne132 import Bjarne132


class Bjarne207(Bjarne132):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "IrhAh"
        
        
        
        self.c = "xbg"
        
        
        
        
        self.f = "8jaRn3"
        
        
        self.g = "l3375P33k"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)