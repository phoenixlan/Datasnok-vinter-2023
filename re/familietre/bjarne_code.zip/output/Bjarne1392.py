
from .Bjarne883 import Bjarne883


class Bjarne1392(Bjarne883):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "IrhAh"
        
        
        
        
        self.e = "p3kop3ko"
        
        
        self.f = "l3375P33k"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)