
from .Bjarne669 import Bjarne669


class Bjarne1712(Bjarne669):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xbg"
        
        
        self.b = "IrhAh"
        
        
        
        self.d = "c00l5sh"
        
        
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)