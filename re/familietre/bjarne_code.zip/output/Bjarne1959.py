
from .Bjarne1170 import Bjarne1170


class Bjarne1959(Bjarne1170):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "k3wL_83An5"
        
        
        self.b = "xbg"
        
        
        self.c = "p3kop3ko"
        
        
        self.d = "8jaRn3"
        
        
        self.e = "Pho3N1X"
        
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)