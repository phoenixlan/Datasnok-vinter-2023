
from .Bjarne485 import Bjarne485


class Bjarne1354(Bjarne485):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        self.b = "1337"
        
        
        self.c = "c00l5sh"
        
        
        self.d = "c00l5sh"
        
        
        self.e = "k3wL_83An5"
        
        
        self.f = "l3375P33k"
        
        
        self.g = "xR4Y"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)