
from .Bjarne146 import Bjarne146


class Bjarne334(Bjarne146):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "l3375P33k"
        
        
        self.c = "xbg"
        
        
        self.d = "k3wL_83An5"
        
        
        self.e = "5w49"
        
        
        self.f = "IrhAh"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)