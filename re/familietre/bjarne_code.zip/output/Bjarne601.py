
from .Bjarne363 import Bjarne363


class Bjarne601(Bjarne363):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        
        
        self.e = "c00l5sh"
        
        
        self.f = "5w4G4d3Ll1c"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)