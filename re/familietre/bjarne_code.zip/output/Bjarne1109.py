
from .Bjarne894 import Bjarne894


class Bjarne1109(Bjarne894):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "1337"
        
        
        self.d = "5w49"
        
        
        self.e = "p3kop3ko"
        
        
        self.f = "1337"
        
        
        self.g = "8jaRn3"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)