
from .Bjarne1004 import Bjarne1004


class Bjarne1190(Bjarne1004):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xbg"
        
        
        
        self.c = "l3375P33k"
        
        
        self.d = "l3375P33k"
        
        
        self.e = "5w4G4d3Ll1c"
        
        
        self.f = "k3wL_83An5"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)