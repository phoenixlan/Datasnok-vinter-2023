
from .Bjarne307 import Bjarne307


class Bjarne1464(Bjarne307):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "p3kop3ko"
        
        
        self.b = "IrhAh"
        
        
        self.c = "xbg"
        
        
        self.d = "l3375P33k"
        
        
        self.e = "8jaRn3"
        
        
        
        self.g = "IrhAh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)