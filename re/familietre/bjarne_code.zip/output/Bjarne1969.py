
from .Bjarne1752 import Bjarne1752


class Bjarne1969(Bjarne1752):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xbg"
        
        
        
        
        self.d = "xR4Y"
        
        
        self.e = "k3wL_83An5"
        
        
        self.f = "5w49"
        
        
        self.g = "Pho3N1X"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)