
from .Bjarne408 import Bjarne408


class Bjarne1768(Bjarne408):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w49"
        
        
        self.b = "IrhAh"
        
        
        self.c = "IrhAh"
        
        
        self.d = "5w4G4d3Ll1c"
        
        
        self.e = "c00l5sh"
        
        
        
        self.g = "1337"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)