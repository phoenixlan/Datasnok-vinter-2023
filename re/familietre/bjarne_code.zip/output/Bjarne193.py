
from .Bjarne83 import Bjarne83


class Bjarne193(Bjarne83):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xbg"
        
        
        self.b = "k3wL_83An5"
        
        
        self.c = "1337"
        
        
        self.d = "IrhAh"
        
        
        self.e = "xR4Y"
        
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)