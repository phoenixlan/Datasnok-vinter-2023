
from .Bjarne947 import Bjarne947


class Bjarne948(Bjarne947):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xR4Y"
        
        
        self.b = "xR4Y"
        
        
        
        self.d = "c00l5sh"
        
        
        self.e = "IrhAh"
        
        
        
        self.g = "l3375P33k"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)