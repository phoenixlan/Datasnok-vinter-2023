
from .Bjarne606 import Bjarne606


class Bjarne1803(Bjarne606):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xR4Y"
        
        
        
        self.c = "l3375P33k"
        
        
        
        self.e = "5w49"
        
        
        self.f = "k3wL_83An5"
        
        
        self.g = "IrhAh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)