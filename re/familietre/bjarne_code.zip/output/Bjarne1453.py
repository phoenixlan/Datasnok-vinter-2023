
from .Bjarne464 import Bjarne464


class Bjarne1453(Bjarne464):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "c00l5sh"
        
        
        self.b = "8jaRn3"
        
        
        self.c = "k3wL_83An5"
        
        
        self.d = "c00l5sh"
        
        
        self.e = "IrhAh"
        
        
        self.f = "IrhAh"
        
        
        self.g = "IrhAh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)