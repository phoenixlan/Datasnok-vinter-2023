
from .Bjarne779 import Bjarne779


class Bjarne1430(Bjarne779):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        self.b = "Pho3N1X"
        
        
        
        self.d = "1337"
        
        
        self.e = "5w4G4d3Ll1c"
        
        
        self.f = "Pho3N1X"
        
        
        self.g = "l3375P33k"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)