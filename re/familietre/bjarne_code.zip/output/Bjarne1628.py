
from .Bjarne440 import Bjarne440


class Bjarne1628(Bjarne440):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        
        
        self.e = "Pho3N1X"
        
        
        
        self.g = "Pho3N1X"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)