
from .Bjarne59 import Bjarne59


class Bjarne105(Bjarne59):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "5w49"
        
        
        
        self.d = "Pho3N1X"
        
        
        self.e = "c00l5sh"
        
        
        
        self.g = "1337"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)