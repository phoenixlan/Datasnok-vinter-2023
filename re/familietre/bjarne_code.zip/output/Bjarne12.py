

class Bjarne12:
    def __init__(self):
        

        
        self.a = "1337"
        
        
        self.b = "Pho3N1X"
        
        
        self.c = "p3kop3ko"
        
        
        self.d = "8jaRn3"
        
        
        self.e = "l3375P33k"
        
        
        self.f = "c00l5sh"
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)