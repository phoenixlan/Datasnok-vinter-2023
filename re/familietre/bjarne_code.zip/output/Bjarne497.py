
from .Bjarne9 import Bjarne9


class Bjarne497(Bjarne9):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xbg"
        
        
        
        self.c = "xbg"
        
        
        self.d = "8jaRn3"
        
        
        
        self.f = "IrhAh"
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)