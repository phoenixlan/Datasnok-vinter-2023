
from .Bjarne102 import Bjarne102


class Bjarne1937(Bjarne102):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "IrhAh"
        
        
        
        self.c = "1337"
        
        
        self.d = "k3wL_83An5"
        
        
        
        self.f = "c00l5sh"
        
        
        self.g = "8jaRn3"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)