
from .Bjarne46 import Bjarne46


class Bjarne700(Bjarne46):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "k3wL_83An5"
        
        
        
        self.e = "xR4Y"
        
        
        self.f = "k3wL_83An5"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)