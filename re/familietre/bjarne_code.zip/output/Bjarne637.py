
from .Bjarne327 import Bjarne327


class Bjarne637(Bjarne327):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "1337"
        
        
        
        self.e = "p3kop3ko"
        
        
        self.f = "k3wL_83An5"
        
        
        self.g = "p3kop3ko"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)