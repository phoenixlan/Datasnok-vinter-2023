
from .Bjarne860 import Bjarne860


class Bjarne986(Bjarne860):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "c00l5sh"
        
        
        self.b = "5w49"
        
        
        
        self.d = "l3375P33k"
        
        
        self.e = "5w49"
        
        
        self.f = "xR4Y"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)