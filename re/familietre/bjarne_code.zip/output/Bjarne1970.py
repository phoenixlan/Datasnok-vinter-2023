
from .Bjarne1182 import Bjarne1182


class Bjarne1970(Bjarne1182):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "l3375P33k"
        
        
        
        self.c = "k3wL_83An5"
        
        
        self.d = "8jaRn3"
        
        
        self.e = "l3375P33k"
        
        
        self.f = "5w49"
        
        
        self.g = "k3wL_83An5"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)