
from .Bjarne1020 import Bjarne1020


class Bjarne1280(Bjarne1020):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "k3wL_83An5"
        
        
        self.b = "Pho3N1X"
        
        
        
        self.d = "xbg"
        
        
        self.e = "Pho3N1X"
        
        
        self.f = "8jaRn3"
        
        
        self.g = "k3wL_83An5"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)