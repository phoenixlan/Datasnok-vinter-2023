
from .Bjarne518 import Bjarne518


class Bjarne788(Bjarne518):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "c00l5sh"
        
        
        
        
        self.d = "c00l5sh"
        
        
        self.e = "k3wL_83An5"
        
        
        self.f = "c00l5sh"
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)