
from .Bjarne640 import Bjarne640


class Bjarne1884(Bjarne640):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w4G4d3Ll1c"
        
        
        self.b = "xbg"
        
        
        self.c = "IrhAh"
        
        
        self.d = "c00l5sh"
        
        
        self.e = "xbg"
        
        
        self.f = "Pho3N1X"
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)