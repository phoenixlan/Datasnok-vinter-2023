
from .Bjarne89 import Bjarne89


class Bjarne579(Bjarne89):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "5w49"
        
        
        
        self.d = "8jaRn3"
        
        
        self.e = "xR4Y"
        
        
        self.f = "c00l5sh"
        
        
        self.g = "p3kop3ko"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)