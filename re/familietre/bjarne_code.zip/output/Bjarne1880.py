
from .Bjarne962 import Bjarne962


class Bjarne1880(Bjarne962):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "IrhAh"
        
        
        self.b = "Pho3N1X"
        
        
        self.c = "xbg"
        
        
        self.d = "c00l5sh"
        
        
        self.e = "xR4Y"
        
        
        self.f = "xR4Y"
        
        
        self.g = "Pho3N1X"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)