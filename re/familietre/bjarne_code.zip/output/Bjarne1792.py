
from .Bjarne61 import Bjarne61


class Bjarne1792(Bjarne61):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "p3kop3ko"
        
        
        self.b = "l3375P33k"
        
        
        self.c = "IrhAh"
        
        
        self.d = "p3kop3ko"
        
        
        
        self.f = "k3wL_83An5"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)