
from .Bjarne161 import Bjarne161


class Bjarne200(Bjarne161):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "xR4Y"
        
        
        self.d = "c00l5sh"
        
        
        self.e = "5w4G4d3Ll1c"
        
        
        self.f = "xbg"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)