
from .Bjarne568 import Bjarne568


class Bjarne1821(Bjarne568):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "xR4Y"
        
        
        self.c = "p3kop3ko"
        
        
        self.d = "IrhAh"
        
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)