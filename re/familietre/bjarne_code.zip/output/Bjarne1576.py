
from .Bjarne940 import Bjarne940


class Bjarne1576(Bjarne940):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "l3375P33k"
        
        
        self.b = "IrhAh"
        
        
        self.c = "8jaRn3"
        
        
        
        self.e = "p3kop3ko"
        
        
        self.f = "IrhAh"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)