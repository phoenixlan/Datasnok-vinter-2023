
from .Bjarne220 import Bjarne220


class Bjarne710(Bjarne220):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "c00l5sh"
        
        
        
        self.d = "p3kop3ko"
        
        
        self.e = "5w49"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)