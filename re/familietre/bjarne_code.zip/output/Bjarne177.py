
from .Bjarne41 import Bjarne41


class Bjarne177(Bjarne41):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xbg"
        
        
        self.b = "IrhAh"
        
        
        self.c = "5w4G4d3Ll1c"
        
        
        self.d = "Pho3N1X"
        
        
        
        
        self.g = "l3375P33k"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)