
from .Bjarne980 import Bjarne980


class Bjarne1263(Bjarne980):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "k3wL_83An5"
        
        
        
        self.c = "Pho3N1X"
        
        
        
        self.e = "p3kop3ko"
        
        
        self.f = "Pho3N1X"
        
        
        self.g = "5w49"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)