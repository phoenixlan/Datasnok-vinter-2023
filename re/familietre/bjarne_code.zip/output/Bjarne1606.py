
from .Bjarne305 import Bjarne305


class Bjarne1606(Bjarne305):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "c00l5sh"
        
        
        self.c = "k3wL_83An5"
        
        
        self.d = "p3kop3ko"
        
        
        self.e = "5w49"
        
        
        self.f = "Pho3N1X"
        
        
        self.g = "5w49"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)