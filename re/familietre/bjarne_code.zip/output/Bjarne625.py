
from .Bjarne332 import Bjarne332


class Bjarne625(Bjarne332):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xR4Y"
        
        
        self.b = "5w4G4d3Ll1c"
        
        
        self.c = "Pho3N1X"
        
        
        self.d = "8jaRn3"
        
        
        self.e = "1337"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)