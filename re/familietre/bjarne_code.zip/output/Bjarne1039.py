
from .Bjarne901 import Bjarne901


class Bjarne1039(Bjarne901):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "p3kop3ko"
        
        
        
        self.d = "k3wL_83An5"
        
        
        
        self.f = "c00l5sh"
        
        
        self.g = "5w49"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)