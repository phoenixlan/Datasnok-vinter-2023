
from .Bjarne56 import Bjarne56


class Bjarne186(Bjarne56):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "xR4Y"
        
        
        self.c = "l3375P33k"
        
        
        self.d = "c00l5sh"
        
        
        self.e = "5w49"
        
        
        self.f = "xR4Y"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)