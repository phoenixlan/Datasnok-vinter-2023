
from .Bjarne1146 import Bjarne1146


class Bjarne1331(Bjarne1146):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "1337"
        
        
        self.b = "8jaRn3"
        
        
        self.c = "l3375P33k"
        
        
        self.d = "8jaRn3"
        
        
        self.e = "5w4G4d3Ll1c"
        
        
        self.f = "l3375P33k"
        
        
        self.g = "IrhAh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)