
from .Bjarne373 import Bjarne373


class Bjarne1234(Bjarne373):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xR4Y"
        
        
        self.b = "Pho3N1X"
        
        
        
        
        self.e = "8jaRn3"
        
        
        self.f = "5w4G4d3Ll1c"
        
        
        self.g = "IrhAh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)