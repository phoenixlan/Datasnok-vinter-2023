
from .Bjarne705 import Bjarne705


class Bjarne1835(Bjarne705):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "Pho3N1X"
        
        
        self.d = "xR4Y"
        
        
        self.e = "5w49"
        
        
        self.f = "5w49"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)