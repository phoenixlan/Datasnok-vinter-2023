
from .Bjarne402 import Bjarne402


class Bjarne1230(Bjarne402):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w49"
        
        
        self.b = "1337"
        
        
        self.c = "p3kop3ko"
        
        
        self.d = "IrhAh"
        
        
        self.e = "Pho3N1X"
        
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)