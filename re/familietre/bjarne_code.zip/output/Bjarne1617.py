
from .Bjarne693 import Bjarne693


class Bjarne1617(Bjarne693):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "8jaRn3"
        
        
        self.d = "IrhAh"
        
        
        self.e = "5w4G4d3Ll1c"
        
        
        self.f = "l3375P33k"
        
        
        self.g = "p3kop3ko"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)