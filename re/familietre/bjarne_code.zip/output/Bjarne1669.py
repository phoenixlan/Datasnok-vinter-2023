
from .Bjarne1107 import Bjarne1107


class Bjarne1669(Bjarne1107):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w49"
        
        
        self.b = "c00l5sh"
        
        
        self.c = "xbg"
        
        
        
        
        self.f = "1337"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)