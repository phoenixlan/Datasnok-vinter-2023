
from .Bjarne1649 import Bjarne1649


class Bjarne1654(Bjarne1649):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "8jaRn3"
        
        
        
        self.c = "p3kop3ko"
        
        
        self.d = "5w49"
        
        
        self.e = "p3kop3ko"
        
        
        
        self.g = "1337"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)