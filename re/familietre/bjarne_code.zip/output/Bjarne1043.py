
from .Bjarne7 import Bjarne7


class Bjarne1043(Bjarne7):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xbg"
        
        
        
        self.c = "xbg"
        
        
        self.d = "5w4G4d3Ll1c"
        
        
        self.e = "c00l5sh"
        
        
        
        self.g = "xR4Y"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)