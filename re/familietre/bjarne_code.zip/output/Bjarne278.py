
from .Bjarne62 import Bjarne62


class Bjarne278(Bjarne62):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "c00l5sh"
        
        
        
        
        self.d = "5w49"
        
        
        self.e = "8jaRn3"
        
        
        self.f = "xR4Y"
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)