
from .Bjarne347 import Bjarne347


class Bjarne799(Bjarne347):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "8jaRn3"
        
        
        self.b = "xR4Y"
        
        
        self.c = "l3375P33k"
        
        
        
        self.e = "xbg"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)