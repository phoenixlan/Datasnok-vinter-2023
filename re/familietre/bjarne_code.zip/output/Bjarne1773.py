
from .Bjarne643 import Bjarne643


class Bjarne1773(Bjarne643):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        self.b = "k3wL_83An5"
        
        
        
        
        self.e = "l3375P33k"
        
        
        self.f = "xR4Y"
        
        
        self.g = "l3375P33k"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)