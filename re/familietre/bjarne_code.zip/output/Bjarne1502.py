
from .Bjarne741 import Bjarne741


class Bjarne1502(Bjarne741):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        self.b = "Pho3N1X"
        
        
        
        self.d = "1337"
        
        
        self.e = "xR4Y"
        
        
        self.f = "xR4Y"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)