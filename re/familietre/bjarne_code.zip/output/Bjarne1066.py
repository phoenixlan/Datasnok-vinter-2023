
from .Bjarne15 import Bjarne15


class Bjarne1066(Bjarne15):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "IrhAh"
        
        
        
        self.c = "IrhAh"
        
        
        self.d = "8jaRn3"
        
        
        self.e = "5w4G4d3Ll1c"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)