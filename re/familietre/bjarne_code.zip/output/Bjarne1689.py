
from .Bjarne1080 import Bjarne1080


class Bjarne1689(Bjarne1080):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        self.b = "xbg"
        
        
        self.c = "p3kop3ko"
        
        
        
        self.e = "c00l5sh"
        
        
        self.f = "xbg"
        
        
        self.g = "l3375P33k"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)