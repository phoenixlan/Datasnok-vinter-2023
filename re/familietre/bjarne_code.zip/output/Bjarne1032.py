
from .Bjarne469 import Bjarne469


class Bjarne1032(Bjarne469):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xR4Y"
        
        
        
        self.c = "IrhAh"
        
        
        self.d = "c00l5sh"
        
        
        self.e = "p3kop3ko"
        
        
        self.f = "5w49"
        
        
        self.g = "xbg"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)