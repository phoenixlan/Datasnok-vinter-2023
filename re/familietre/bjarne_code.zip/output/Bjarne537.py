
from .Bjarne103 import Bjarne103


class Bjarne537(Bjarne103):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        self.b = "1337"
        
        
        self.c = "5w49"
        
        
        self.d = "5w4G4d3Ll1c"
        
        
        self.e = "IrhAh"
        
        
        self.f = "xR4Y"
        
        
        self.g = "l3375P33k"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)