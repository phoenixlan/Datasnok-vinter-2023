
from .Bjarne406 import Bjarne406


class Bjarne1702(Bjarne406):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "1337"
        
        
        self.b = "l3375P33k"
        
        
        
        self.d = "8jaRn3"
        
        
        self.e = "p3kop3ko"
        
        
        self.f = "k3wL_83An5"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)