
from .Bjarne23 import Bjarne23


class Bjarne711(Bjarne23):
    def __init__(self):
        

        
        self.a = "p3kop3ko"
        
        
        self.b = "l3375P33k"
        
        
        self.c = "5w4G4d3Ll1c"
        
        
        self.d = "l3375P33k"
        
        
        
        self.f = "xbg"
        
        
        self.g = "p3kop3ko"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)