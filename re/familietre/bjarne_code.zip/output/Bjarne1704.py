
from .Bjarne667 import Bjarne667


class Bjarne1704(Bjarne667):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "Pho3N1X"
        
        
        self.c = "xR4Y"
        
        
        self.d = "IrhAh"
        
        
        self.e = "8jaRn3"
        
        
        self.f = "xR4Y"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)