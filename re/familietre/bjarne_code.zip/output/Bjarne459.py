
from .Bjarne98 import Bjarne98


class Bjarne459(Bjarne98):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "xR4Y"
        
        
        self.c = "c00l5sh"
        
        
        self.d = "xbg"
        
        
        self.e = "Pho3N1X"
        
        
        self.f = "p3kop3ko"
        
        
        self.g = "5w49"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)