
from .Bjarne209 import Bjarne209


class Bjarne621(Bjarne209):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        
        
        self.e = "xbg"
        
        
        self.f = "8jaRn3"
        
        
        self.g = "5w49"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)