
from .Bjarne415 import Bjarne415


class Bjarne892(Bjarne415):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "8jaRn3"
        
        
        
        
        
        self.g = "IrhAh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)