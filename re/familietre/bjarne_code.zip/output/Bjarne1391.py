
from .Bjarne372 import Bjarne372


class Bjarne1391(Bjarne372):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "p3kop3ko"
        
        
        self.c = "xbg"
        
        
        
        
        self.f = "xbg"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)