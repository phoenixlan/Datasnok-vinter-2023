
from .Bjarne112 import Bjarne112


class Bjarne852(Bjarne112):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w49"
        
        
        self.b = "5w49"
        
        
        self.c = "8jaRn3"
        
        
        self.d = "k3wL_83An5"
        
        
        
        self.f = "xbg"
        
        
        self.g = "k3wL_83An5"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)