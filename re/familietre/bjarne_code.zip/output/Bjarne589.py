
from .Bjarne203 import Bjarne203


class Bjarne589(Bjarne203):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "k3wL_83An5"
        
        
        self.b = "l3375P33k"
        
        
        self.c = "l3375P33k"
        
        
        self.d = "IrhAh"
        
        
        self.e = "IrhAh"
        
        
        self.f = "k3wL_83An5"
        
        
        self.g = "l3375P33k"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)