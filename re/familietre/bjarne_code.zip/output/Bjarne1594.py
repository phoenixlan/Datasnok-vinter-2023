
from .Bjarne529 import Bjarne529


class Bjarne1594(Bjarne529):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "p3kop3ko"
        
        
        
        self.c = "8jaRn3"
        
        
        self.d = "c00l5sh"
        
        
        self.e = "Pho3N1X"
        
        
        self.f = "xR4Y"
        
        
        self.g = "k3wL_83An5"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)