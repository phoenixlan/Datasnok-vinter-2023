
from .Bjarne692 import Bjarne692


class Bjarne1144(Bjarne692):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "p3kop3ko"
        
        
        self.b = "Pho3N1X"
        
        
        self.c = "8jaRn3"
        
        
        self.d = "p3kop3ko"
        
        
        
        self.f = "c00l5sh"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)