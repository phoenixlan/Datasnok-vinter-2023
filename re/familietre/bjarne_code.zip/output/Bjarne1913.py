
from .Bjarne577 import Bjarne577


class Bjarne1913(Bjarne577):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "5w4G4d3Ll1c"
        
        
        self.c = "5w4G4d3Ll1c"
        
        
        self.d = "c00l5sh"
        
        
        self.e = "5w49"
        
        
        self.f = "k3wL_83An5"
        
        
        self.g = "8jaRn3"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)