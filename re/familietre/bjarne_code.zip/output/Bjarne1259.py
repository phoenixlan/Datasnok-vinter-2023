
from .Bjarne1085 import Bjarne1085


class Bjarne1259(Bjarne1085):
    def __init__(self):
        

        
        self.a = "Pho3N1X"
        
        
        
        self.c = "xbg"
        
        
        
        self.e = "5w4G4d3Ll1c"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)