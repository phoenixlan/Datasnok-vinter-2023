
from .Bjarne856 import Bjarne856


class Bjarne923(Bjarne856):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "8jaRn3"
        
        
        
        
        self.e = "k3wL_83An5"
        
        
        self.f = "k3wL_83An5"
        
        
        self.g = "l3375P33k"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)