
from .Bjarne24 import Bjarne24


class Bjarne399(Bjarne24):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "5w49"
        
        
        
        
        self.e = "Pho3N1X"
        
        
        self.f = "1337"
        
        
        self.g = "Pho3N1X"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)