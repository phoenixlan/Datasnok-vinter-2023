

class Bjarne44:
    def __init__(self):
        

        
        self.a = "1337"
        
        
        self.b = "8jaRn3"
        
        
        self.c = "IrhAh"
        
        
        self.d = "k3wL_83An5"
        
        
        self.e = "8jaRn3"
        
        
        self.f = "xbg"
        
        
        self.g = "IrhAh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)