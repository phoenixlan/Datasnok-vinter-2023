
from .Bjarne240 import Bjarne240


class Bjarne1248(Bjarne240):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "xbg"
        
        
        self.c = "k3wL_83An5"
        
        
        self.d = "IrhAh"
        
        
        self.e = "l3375P33k"
        
        
        self.f = "xbg"
        
        
        self.g = "k3wL_83An5"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)