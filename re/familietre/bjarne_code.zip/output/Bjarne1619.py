
from .Bjarne622 import Bjarne622


class Bjarne1619(Bjarne622):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "c00l5sh"
        
        
        
        self.c = "1337"
        
        
        self.d = "5w49"
        
        
        self.e = "xR4Y"
        
        
        self.f = "xR4Y"
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)