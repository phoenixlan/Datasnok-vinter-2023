
from .Bjarne201 import Bjarne201


class Bjarne1096(Bjarne201):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "p3kop3ko"
        
        
        self.b = "1337"
        
        
        self.c = "l3375P33k"
        
        
        
        
        self.f = "IrhAh"
        
        
        self.g = "l3375P33k"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)