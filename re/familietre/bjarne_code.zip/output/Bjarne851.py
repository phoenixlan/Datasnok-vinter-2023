
from .Bjarne66 import Bjarne66


class Bjarne851(Bjarne66):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "IrhAh"
        
        
        
        self.c = "5w49"
        
        
        
        self.e = "5w49"
        
        
        
        self.g = "p3kop3ko"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)