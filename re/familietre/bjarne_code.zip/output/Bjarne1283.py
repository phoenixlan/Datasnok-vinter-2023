
from .Bjarne432 import Bjarne432


class Bjarne1283(Bjarne432):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "l3375P33k"
        
        
        self.b = "5w4G4d3Ll1c"
        
        
        self.c = "p3kop3ko"
        
        
        self.d = "l3375P33k"
        
        
        self.e = "8jaRn3"
        
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)