
from .Bjarne300 import Bjarne300


class Bjarne340(Bjarne300):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "IrhAh"
        
        
        self.b = "xbg"
        
        
        
        self.d = "xbg"
        
        
        self.e = "5w4G4d3Ll1c"
        
        
        self.f = "p3kop3ko"
        
        
        self.g = "8jaRn3"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)