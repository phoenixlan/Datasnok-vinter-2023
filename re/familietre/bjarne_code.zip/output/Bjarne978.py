
from .Bjarne871 import Bjarne871


class Bjarne978(Bjarne871):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "p3kop3ko"
        
        
        self.b = "8jaRn3"
        
        
        self.c = "p3kop3ko"
        
        
        self.d = "c00l5sh"
        
        
        self.e = "xR4Y"
        
        
        self.f = "k3wL_83An5"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)