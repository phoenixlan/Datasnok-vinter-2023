
from .Bjarne723 import Bjarne723


class Bjarne1199(Bjarne723):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        self.b = "Pho3N1X"
        
        
        
        
        self.e = "l3375P33k"
        
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)