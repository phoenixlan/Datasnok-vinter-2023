
from .Bjarne616 import Bjarne616


class Bjarne891(Bjarne616):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        
        
        self.d = "IrhAh"
        
        
        self.e = "p3kop3ko"
        
        
        self.f = "c00l5sh"
        
        
        self.g = "IrhAh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)