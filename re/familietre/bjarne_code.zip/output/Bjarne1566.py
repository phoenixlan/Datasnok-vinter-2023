
from .Bjarne1400 import Bjarne1400


class Bjarne1566(Bjarne1400):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w4G4d3Ll1c"
        
        
        self.b = "xbg"
        
        
        
        self.d = "xR4Y"
        
        
        self.e = "5w4G4d3Ll1c"
        
        
        self.f = "5w49"
        
        
        self.g = "Pho3N1X"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)