
from .Bjarne1151 import Bjarne1151


class Bjarne1926(Bjarne1151):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        
        self.c = "c00l5sh"
        
        
        self.d = "IrhAh"
        
        
        self.e = "8jaRn3"
        
        
        self.f = "k3wL_83An5"
        
        
        self.g = "xR4Y"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)