
from .Bjarne613 import Bjarne613


class Bjarne1995(Bjarne613):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "IrhAh"
        
        
        self.d = "5w4G4d3Ll1c"
        
        
        self.e = "1337"
        
        
        self.f = "xbg"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)