
from .Bjarne564 import Bjarne564


class Bjarne877(Bjarne564):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "1337"
        
        
        
        self.c = "8jaRn3"
        
        
        self.d = "5w49"
        
        
        self.e = "p3kop3ko"
        
        
        self.f = "k3wL_83An5"
        
        
        self.g = "p3kop3ko"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)