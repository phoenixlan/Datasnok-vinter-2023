
from .Bjarne1165 import Bjarne1165


class Bjarne1523(Bjarne1165):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "IrhAh"
        
        
        self.b = "1337"
        
        
        self.c = "p3kop3ko"
        
        
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)