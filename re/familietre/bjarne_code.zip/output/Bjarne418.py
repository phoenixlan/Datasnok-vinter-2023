
from .Bjarne103 import Bjarne103


class Bjarne418(Bjarne103):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "p3kop3ko"
        
        
        self.c = "xbg"
        
        
        
        self.e = "p3kop3ko"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)