
from .Bjarne966 import Bjarne966


class Bjarne1155(Bjarne966):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xR4Y"
        
        
        
        
        self.d = "p3kop3ko"
        
        
        self.e = "l3375P33k"
        
        
        
        self.g = "Pho3N1X"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)