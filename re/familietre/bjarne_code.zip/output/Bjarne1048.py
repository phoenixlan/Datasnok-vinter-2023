
from .Bjarne117 import Bjarne117


class Bjarne1048(Bjarne117):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        self.b = "IrhAh"
        
        
        self.c = "1337"
        
        
        self.d = "xbg"
        
        
        self.e = "c00l5sh"
        
        
        self.f = "8jaRn3"
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)