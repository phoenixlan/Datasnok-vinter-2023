
from .Bjarne529 import Bjarne529


class Bjarne591(Bjarne529):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        self.b = "IrhAh"
        
        
        self.c = "k3wL_83An5"
        
        
        
        self.e = "p3kop3ko"
        
        
        self.f = "xR4Y"
        
        
        self.g = "1337"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)