
from .Bjarne91 import Bjarne91


class Bjarne323(Bjarne91):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "p3kop3ko"
        
        
        self.d = "xbg"
        
        
        self.e = "5w4G4d3Ll1c"
        
        
        self.f = "l3375P33k"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)