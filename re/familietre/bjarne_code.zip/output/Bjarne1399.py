
from .Bjarne810 import Bjarne810


class Bjarne1399(Bjarne810):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xR4Y"
        
        
        self.b = "l3375P33k"
        
        
        self.c = "c00l5sh"
        
        
        
        self.e = "IrhAh"
        
        
        
        self.g = "xbg"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)