
from .Bjarne52 import Bjarne52


class Bjarne697(Bjarne52):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "c00l5sh"
        
        
        self.b = "l3375P33k"
        
        
        
        self.d = "IrhAh"
        
        
        self.e = "5w4G4d3Ll1c"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)