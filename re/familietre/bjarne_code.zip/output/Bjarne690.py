
from .Bjarne416 import Bjarne416


class Bjarne690(Bjarne416):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "k3wL_83An5"
        
        
        
        self.d = "1337"
        
        
        
        self.f = "xbg"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)