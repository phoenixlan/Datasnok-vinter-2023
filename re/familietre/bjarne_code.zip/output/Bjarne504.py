
from .Bjarne280 import Bjarne280


class Bjarne504(Bjarne280):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "p3kop3ko"
        
        
        self.b = "8jaRn3"
        
        
        
        self.d = "Pho3N1X"
        
        
        self.e = "IrhAh"
        
        
        
        self.g = "p3kop3ko"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)