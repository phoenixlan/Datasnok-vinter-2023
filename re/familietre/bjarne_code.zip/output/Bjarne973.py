
from .Bjarne89 import Bjarne89


class Bjarne973(Bjarne89):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w49"
        
        
        self.b = "IrhAh"
        
        
        self.c = "xbg"
        
        
        
        
        self.f = "p3kop3ko"
        
        
        self.g = "xR4Y"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)