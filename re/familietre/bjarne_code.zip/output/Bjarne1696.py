
from .Bjarne1415 import Bjarne1415


class Bjarne1696(Bjarne1415):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "1337"
        
        
        
        self.c = "1337"
        
        
        
        self.e = "1337"
        
        
        self.f = "8jaRn3"
        
        
        self.g = "xbg"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)