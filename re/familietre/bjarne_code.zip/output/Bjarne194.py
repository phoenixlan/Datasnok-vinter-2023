
from .Bjarne124 import Bjarne124


class Bjarne194(Bjarne124):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "l3375P33k"
        
        
        
        self.c = "5w49"
        
        
        
        
        
        self.g = "IrhAh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)