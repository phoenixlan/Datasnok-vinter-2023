
from .Bjarne867 import Bjarne867


class Bjarne1751(Bjarne867):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "c00l5sh"
        
        
        self.b = "xR4Y"
        
        
        self.c = "1337"
        
        
        
        self.e = "8jaRn3"
        
        
        self.f = "l3375P33k"
        
        
        self.g = "xR4Y"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)