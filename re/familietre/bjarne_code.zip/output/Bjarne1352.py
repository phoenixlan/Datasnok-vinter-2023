
from .Bjarne801 import Bjarne801


class Bjarne1352(Bjarne801):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "1337"
        
        
        self.d = "5w4G4d3Ll1c"
        
        
        
        self.f = "Pho3N1X"
        
        
        self.g = "IrhAh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)