
from .Bjarne101 import Bjarne101


class Bjarne550(Bjarne101):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "l3375P33k"
        
        
        
        
        self.e = "Pho3N1X"
        
        
        self.f = "c00l5sh"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)