
from .Bjarne606 import Bjarne606


class Bjarne1178(Bjarne606):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        self.b = "5w4G4d3Ll1c"
        
        
        
        
        self.e = "IrhAh"
        
        
        self.f = "1337"
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)