
from .Bjarne570 import Bjarne570


class Bjarne715(Bjarne570):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "l3375P33k"
        
        
        self.b = "xbg"
        
        
        self.c = "Pho3N1X"
        
        
        self.d = "5w49"
        
        
        self.e = "l3375P33k"
        
        
        
        self.g = "k3wL_83An5"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)