
from .Bjarne842 import Bjarne842


class Bjarne1027(Bjarne842):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w49"
        
        
        
        self.c = "8jaRn3"
        
        
        self.d = "1337"
        
        
        self.e = "xbg"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)