

class Bjarne73:
    def __init__(self):
        

        
        self.a = "k3wL_83An5"
        
        
        self.b = "xR4Y"
        
        
        self.c = "xR4Y"
        
        
        self.d = "5w49"
        
        
        self.e = "l3375P33k"
        
        
        self.f = "8jaRn3"
        
        
        self.g = "Pho3N1X"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)