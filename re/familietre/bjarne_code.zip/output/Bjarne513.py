
from .Bjarne359 import Bjarne359


class Bjarne513(Bjarne359):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w49"
        
        
        self.b = "5w49"
        
        
        
        
        self.e = "k3wL_83An5"
        
        
        self.f = "8jaRn3"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)