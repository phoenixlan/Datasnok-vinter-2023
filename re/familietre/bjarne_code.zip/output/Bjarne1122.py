
from .Bjarne966 import Bjarne966


class Bjarne1122(Bjarne966):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "IrhAh"
        
        
        self.b = "l3375P33k"
        
        
        self.c = "IrhAh"
        
        
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)