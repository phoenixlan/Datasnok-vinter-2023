
from .Bjarne743 import Bjarne743


class Bjarne1997(Bjarne743):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xbg"
        
        
        
        self.c = "l3375P33k"
        
        
        self.d = "5w49"
        
        
        self.e = "l3375P33k"
        
        
        self.f = "IrhAh"
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)