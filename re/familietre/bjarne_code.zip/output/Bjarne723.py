
from .Bjarne64 import Bjarne64


class Bjarne723(Bjarne64):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w4G4d3Ll1c"
        
        
        self.b = "IrhAh"
        
        
        
        self.d = "5w49"
        
        
        self.e = "p3kop3ko"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)