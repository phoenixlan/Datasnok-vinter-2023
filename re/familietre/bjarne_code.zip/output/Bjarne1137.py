
from .Bjarne1066 import Bjarne1066


class Bjarne1137(Bjarne1066):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "p3kop3ko"
        
        
        
        self.c = "1337"
        
        
        self.d = "xbg"
        
        
        self.e = "5w4G4d3Ll1c"
        
        
        self.f = "xR4Y"
        
        
        self.g = "l3375P33k"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)