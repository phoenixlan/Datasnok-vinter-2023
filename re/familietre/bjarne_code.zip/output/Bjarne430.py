
from .Bjarne306 import Bjarne306


class Bjarne430(Bjarne306):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "c00l5sh"
        
        
        self.c = "8jaRn3"
        
        
        
        self.e = "8jaRn3"
        
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)