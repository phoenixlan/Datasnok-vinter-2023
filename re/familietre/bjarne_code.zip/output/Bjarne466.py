
from .Bjarne237 import Bjarne237


class Bjarne466(Bjarne237):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xR4Y"
        
        
        self.b = "IrhAh"
        
        
        self.c = "8jaRn3"
        
        
        self.d = "k3wL_83An5"
        
        
        
        self.f = "IrhAh"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)