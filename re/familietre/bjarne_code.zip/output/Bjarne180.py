
from .Bjarne63 import Bjarne63


class Bjarne180(Bjarne63):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "c00l5sh"
        
        
        self.b = "xbg"
        
        
        self.c = "1337"
        
        
        self.d = "Pho3N1X"
        
        
        self.e = "c00l5sh"
        
        
        
        self.g = "IrhAh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)