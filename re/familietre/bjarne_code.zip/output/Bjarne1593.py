
from .Bjarne1222 import Bjarne1222


class Bjarne1593(Bjarne1222):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "xR4Y"
        
        
        self.d = "5w4G4d3Ll1c"
        
        
        self.e = "xbg"
        
        
        self.f = "1337"
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)