
from .Bjarne1007 import Bjarne1007


class Bjarne1366(Bjarne1007):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "k3wL_83An5"
        
        
        self.b = "p3kop3ko"
        
        
        self.c = "IrhAh"
        
        
        
        
        self.f = "Pho3N1X"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)