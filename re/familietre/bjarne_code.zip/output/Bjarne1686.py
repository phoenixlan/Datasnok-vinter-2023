
from .Bjarne608 import Bjarne608


class Bjarne1686(Bjarne608):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "5w4G4d3Ll1c"
        
        
        
        self.d = "Pho3N1X"
        
        
        
        self.f = "xbg"
        
        
        self.g = "p3kop3ko"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)