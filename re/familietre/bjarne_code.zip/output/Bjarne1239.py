
from .Bjarne892 import Bjarne892


class Bjarne1239(Bjarne892):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "IrhAh"
        
        
        self.b = "1337"
        
        
        self.c = "5w4G4d3Ll1c"
        
        
        self.d = "p3kop3ko"
        
        
        self.e = "l3375P33k"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)