
from .Bjarne52 import Bjarne52


class Bjarne1029(Bjarne52):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "1337"
        
        
        self.b = "c00l5sh"
        
        
        self.c = "l3375P33k"
        
        
        self.d = "Pho3N1X"
        
        
        
        self.f = "Pho3N1X"
        
        
        self.g = "8jaRn3"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)