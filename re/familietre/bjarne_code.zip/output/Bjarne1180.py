
from .Bjarne637 import Bjarne637


class Bjarne1180(Bjarne637):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "8jaRn3"
        
        
        self.c = "c00l5sh"
        
        
        
        self.e = "xbg"
        
        
        self.f = "k3wL_83An5"
        
        
        self.g = "xR4Y"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)