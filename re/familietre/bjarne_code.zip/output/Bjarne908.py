
from .Bjarne875 import Bjarne875


class Bjarne908(Bjarne875):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "l3375P33k"
        
        
        
        self.d = "k3wL_83An5"
        
        
        self.e = "5w49"
        
        
        self.f = "c00l5sh"
        
        
        self.g = "xbg"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)