
from .Bjarne54 import Bjarne54


class Bjarne959(Bjarne54):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        
        
        self.e = "c00l5sh"
        
        
        self.f = "Pho3N1X"
        
        
        self.g = "xbg"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)