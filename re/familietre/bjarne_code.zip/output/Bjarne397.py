
from .Bjarne213 import Bjarne213


class Bjarne397(Bjarne213):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w49"
        
        
        
        
        self.d = "1337"
        
        
        self.e = "5w49"
        
        
        self.f = "c00l5sh"
        
        
        self.g = "1337"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)