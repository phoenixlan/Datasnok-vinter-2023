
from .Bjarne1630 import Bjarne1630


class Bjarne1910(Bjarne1630):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        self.b = "Pho3N1X"
        
        
        
        self.d = "8jaRn3"
        
        
        self.e = "1337"
        
        
        self.f = "5w4G4d3Ll1c"
        
        
        self.g = "8jaRn3"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)