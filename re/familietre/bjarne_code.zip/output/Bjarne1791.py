
from .Bjarne177 import Bjarne177


class Bjarne1791(Bjarne177):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "p3kop3ko"
        
        
        self.c = "c00l5sh"
        
        
        self.d = "5w49"
        
        
        
        self.f = "Pho3N1X"
        
        
        self.g = "8jaRn3"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)