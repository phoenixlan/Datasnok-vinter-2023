
from .Bjarne279 import Bjarne279


class Bjarne1015(Bjarne279):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w4G4d3Ll1c"
        
        
        self.b = "p3kop3ko"
        
        
        self.c = "xbg"
        
        
        self.d = "5w4G4d3Ll1c"
        
        
        
        self.f = "l3375P33k"
        
        
        self.g = "Pho3N1X"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)