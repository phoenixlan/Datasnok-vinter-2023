
from .Bjarne123 import Bjarne123


class Bjarne462(Bjarne123):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "c00l5sh"
        
        
        self.b = "k3wL_83An5"
        
        
        self.c = "IrhAh"
        
        
        self.d = "8jaRn3"
        
        
        
        
        self.g = "1337"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)