
from .Bjarne32 import Bjarne32


class Bjarne280(Bjarne32):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xbg"
        
        
        self.b = "5w49"
        
        
        self.c = "xbg"
        
        
        
        
        self.f = "IrhAh"
        
        
        self.g = "IrhAh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)