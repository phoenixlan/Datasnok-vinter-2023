
from .Bjarne64 import Bjarne64


class Bjarne392(Bjarne64):
    def __init__(self):
        

        
        
        self.b = "5w49"
        
        
        self.c = "xbg"
        
        
        
        
        self.f = "c00l5sh"
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)