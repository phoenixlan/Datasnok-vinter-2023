
from .Bjarne918 import Bjarne918


class Bjarne1162(Bjarne918):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xbg"
        
        
        self.b = "8jaRn3"
        
        
        
        
        self.e = "k3wL_83An5"
        
        
        self.f = "c00l5sh"
        
        
        self.g = "xbg"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)