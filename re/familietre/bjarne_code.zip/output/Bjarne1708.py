
from .Bjarne1227 import Bjarne1227


class Bjarne1708(Bjarne1227):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "l3375P33k"
        
        
        self.b = "l3375P33k"
        
        
        self.c = "c00l5sh"
        
        
        self.d = "8jaRn3"
        
        
        
        
        self.g = "Pho3N1X"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)