
from .Bjarne1835 import Bjarne1835


class Bjarne1901(Bjarne1835):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "k3wL_83An5"
        
        
        self.b = "5w4G4d3Ll1c"
        
        
        self.c = "1337"
        
        
        self.d = "l3375P33k"
        
        
        self.e = "c00l5sh"
        
        
        self.f = "xR4Y"
        
        
        self.g = "l3375P33k"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)