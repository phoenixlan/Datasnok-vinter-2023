
from .Bjarne235 import Bjarne235


class Bjarne1168(Bjarne235):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xR4Y"
        
        
        
        self.c = "Pho3N1X"
        
        
        self.d = "xbg"
        
        
        
        self.f = "p3kop3ko"
        
        
        self.g = "5w49"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)