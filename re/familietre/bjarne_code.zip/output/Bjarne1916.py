
from .Bjarne1731 import Bjarne1731


class Bjarne1916(Bjarne1731):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "l3375P33k"
        
        
        self.d = "xbg"
        
        
        self.e = "c00l5sh"
        
        
        self.f = "5w4G4d3Ll1c"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)