
from .Bjarne283 import Bjarne283


class Bjarne380(Bjarne283):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "8jaRn3"
        
        
        self.b = "k3wL_83An5"
        
        
        self.c = "8jaRn3"
        
        
        
        self.e = "1337"
        
        
        self.f = "5w49"
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)