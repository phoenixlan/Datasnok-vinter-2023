
from .Bjarne57 import Bjarne57


class Bjarne402(Bjarne57):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "5w4G4d3Ll1c"
        
        
        
        self.e = "IrhAh"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)