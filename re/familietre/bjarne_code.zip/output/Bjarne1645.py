
from .Bjarne1217 import Bjarne1217


class Bjarne1645(Bjarne1217):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "k3wL_83An5"
        
        
        
        
        self.f = "c00l5sh"
        
        
        self.g = "xbg"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)