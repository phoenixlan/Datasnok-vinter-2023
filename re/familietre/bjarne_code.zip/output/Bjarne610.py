
from .Bjarne486 import Bjarne486


class Bjarne610(Bjarne486):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "8jaRn3"
        
        
        
        self.c = "l3375P33k"
        
        
        self.d = "5w49"
        
        
        self.e = "5w49"
        
        
        self.f = "l3375P33k"
        
        
        self.g = "xbg"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)