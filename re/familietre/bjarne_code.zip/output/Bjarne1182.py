
from .Bjarne971 import Bjarne971


class Bjarne1182(Bjarne971):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w4G4d3Ll1c"
        
        
        self.b = "l3375P33k"
        
        
        
        
        self.e = "p3kop3ko"
        
        
        
        self.g = "1337"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)