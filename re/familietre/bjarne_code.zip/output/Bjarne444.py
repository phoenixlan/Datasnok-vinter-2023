
from .Bjarne412 import Bjarne412


class Bjarne444(Bjarne412):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        self.b = "p3kop3ko"
        
        
        self.c = "Pho3N1X"
        
        
        self.d = "p3kop3ko"
        
        
        self.e = "l3375P33k"
        
        
        self.f = "5w49"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)