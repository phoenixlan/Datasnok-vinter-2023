
from .Bjarne968 import Bjarne968


class Bjarne1211(Bjarne968):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xbg"
        
        
        self.b = "k3wL_83An5"
        
        
        self.c = "1337"
        
        
        
        
        self.f = "xR4Y"
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)