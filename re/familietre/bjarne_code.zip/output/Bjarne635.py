
from .Bjarne27 import Bjarne27


class Bjarne635(Bjarne27):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "1337"
        
        
        self.b = "8jaRn3"
        
        
        self.c = "l3375P33k"
        
        
        self.d = "l3375P33k"
        
        
        self.e = "1337"
        
        
        self.f = "c00l5sh"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)