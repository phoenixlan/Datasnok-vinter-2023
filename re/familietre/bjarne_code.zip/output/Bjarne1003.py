
from .Bjarne559 import Bjarne559


class Bjarne1003(Bjarne559):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "c00l5sh"
        
        
        self.c = "8jaRn3"
        
        
        self.d = "5w4G4d3Ll1c"
        
        
        
        self.f = "5w4G4d3Ll1c"
        
        
        self.g = "1337"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)