
from .Bjarne727 import Bjarne727


class Bjarne1580(Bjarne727):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "1337"
        
        
        
        
        self.d = "Pho3N1X"
        
        
        self.e = "c00l5sh"
        
        
        self.f = "xR4Y"
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)