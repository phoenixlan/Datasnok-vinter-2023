
from .Bjarne308 import Bjarne308


class Bjarne1378(Bjarne308):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w49"
        
        
        
        self.c = "c00l5sh"
        
        
        self.d = "5w49"
        
        
        self.e = "l3375P33k"
        
        
        self.f = "k3wL_83An5"
        
        
        self.g = "xbg"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)