
from .Bjarne507 import Bjarne507


class Bjarne532(Bjarne507):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "8jaRn3"
        
        
        self.b = "1337"
        
        
        self.c = "5w49"
        
        
        self.d = "p3kop3ko"
        
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)