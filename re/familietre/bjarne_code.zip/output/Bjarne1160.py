
from .Bjarne783 import Bjarne783


class Bjarne1160(Bjarne783):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "p3kop3ko"
        
        
        self.b = "8jaRn3"
        
        
        self.c = "xR4Y"
        
        
        self.d = "xbg"
        
        
        
        self.f = "IrhAh"
        
        
        self.g = "Pho3N1X"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)