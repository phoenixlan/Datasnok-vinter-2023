
from .Bjarne391 import Bjarne391


class Bjarne617(Bjarne391):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "k3wL_83An5"
        
        
        
        
        self.f = "5w49"
        
        
        self.g = "Pho3N1X"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)