
from .Bjarne567 import Bjarne567


class Bjarne703(Bjarne567):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w49"
        
        
        self.b = "k3wL_83An5"
        
        
        
        
        self.e = "8jaRn3"
        
        
        self.f = "xR4Y"
        
        
        self.g = "xbg"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)