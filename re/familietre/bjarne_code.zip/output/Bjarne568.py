
from .Bjarne119 import Bjarne119


class Bjarne568(Bjarne119):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        
        self.c = "IrhAh"
        
        
        
        self.e = "IrhAh"
        
        
        
        self.g = "l3375P33k"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)