
from .Bjarne516 import Bjarne516


class Bjarne1706(Bjarne516):
    def __init__(self):
        

        
        self.a = "xbg"
        
        
        self.b = "xbg"
        
        
        self.c = "5w49"
        
        
        self.d = "c00l5sh"
        
        
        self.e = "Pho3N1X"
        
        
        self.f = "1337"
        
        
        self.g = "p3kop3ko"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)