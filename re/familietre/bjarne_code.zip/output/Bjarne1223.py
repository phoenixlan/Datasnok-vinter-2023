
from .Bjarne472 import Bjarne472


class Bjarne1223(Bjarne472):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "5w4G4d3Ll1c"
        
        
        self.c = "xbg"
        
        
        self.d = "p3kop3ko"
        
        
        self.e = "l3375P33k"
        
        
        self.f = "1337"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)