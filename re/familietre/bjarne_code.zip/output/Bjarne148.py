
from .Bjarne25 import Bjarne25


class Bjarne148(Bjarne25):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "IrhAh"
        
        
        
        self.c = "p3kop3ko"
        
        
        self.d = "Pho3N1X"
        
        
        self.e = "1337"
        
        
        self.f = "8jaRn3"
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)