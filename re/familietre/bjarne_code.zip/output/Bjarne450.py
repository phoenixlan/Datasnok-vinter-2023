
from .Bjarne247 import Bjarne247


class Bjarne450(Bjarne247):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xbg"
        
        
        self.b = "xbg"
        
        
        self.c = "5w49"
        
        
        
        self.e = "8jaRn3"
        
        
        self.f = "c00l5sh"
        
        
        self.g = "8jaRn3"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)