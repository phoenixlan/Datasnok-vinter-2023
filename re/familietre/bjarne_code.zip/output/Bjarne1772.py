
from .Bjarne1009 import Bjarne1009


class Bjarne1772(Bjarne1009):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xbg"
        
        
        self.b = "5w4G4d3Ll1c"
        
        
        
        self.d = "IrhAh"
        
        
        self.e = "5w4G4d3Ll1c"
        
        
        
        self.g = "l3375P33k"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)