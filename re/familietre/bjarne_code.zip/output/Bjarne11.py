

class Bjarne11:
    def __init__(self):
        

        
        self.a = "1337"
        
        
        self.b = "IrhAh"
        
        
        self.c = "8jaRn3"
        
        
        self.d = "k3wL_83An5"
        
        
        self.e = "5w49"
        
        
        self.f = "8jaRn3"
        
        
        self.g = "k3wL_83An5"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)