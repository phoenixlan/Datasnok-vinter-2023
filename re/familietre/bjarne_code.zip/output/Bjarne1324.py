
from .Bjarne999 import Bjarne999


class Bjarne1324(Bjarne999):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "8jaRn3"
        
        
        
        self.c = "k3wL_83An5"
        
        
        self.d = "c00l5sh"
        
        
        
        self.f = "p3kop3ko"
        
        
        self.g = "8jaRn3"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)