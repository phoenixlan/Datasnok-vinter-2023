
from .Bjarne39 import Bjarne39


class Bjarne122(Bjarne39):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "IrhAh"
        
        
        self.c = "Pho3N1X"
        
        
        self.d = "l3375P33k"
        
        
        self.e = "c00l5sh"
        
        
        self.f = "xbg"
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)