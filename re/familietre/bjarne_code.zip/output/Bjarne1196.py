
from .Bjarne737 import Bjarne737


class Bjarne1196(Bjarne737):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        
        self.d = "1337"
        
        
        self.e = "8jaRn3"
        
        
        self.f = "IrhAh"
        
        
        self.g = "c00l5sh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)