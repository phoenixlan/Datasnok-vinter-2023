
from .Bjarne235 import Bjarne235


class Bjarne531(Bjarne235):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "l3375P33k"
        
        
        
        self.c = "p3kop3ko"
        
        
        
        self.e = "c00l5sh"
        
        
        self.f = "c00l5sh"
        
        
        self.g = "5w49"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)