

class Bjarne87:
    def __init__(self):
        

        
        self.a = "5w49"
        
        
        self.b = "k3wL_83An5"
        
        
        self.c = "IrhAh"
        
        
        self.d = "p3kop3ko"
        
        
        self.e = "xbg"
        
        
        self.f = "8jaRn3"
        
        
        self.g = "5w49"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)