
from .Bjarne463 import Bjarne463


class Bjarne1300(Bjarne463):
    def __init__(self):
        

        
        self.a = "5w49"
        
        
        
        self.c = "IrhAh"
        
        
        
        self.e = "k3wL_83An5"
        
        
        self.f = "1337"
        
        
        self.g = "k3wL_83An5"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)