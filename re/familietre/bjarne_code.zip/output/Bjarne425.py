
from .Bjarne278 import Bjarne278


class Bjarne425(Bjarne278):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xbg"
        
        
        self.b = "Pho3N1X"
        
        
        self.c = "xR4Y"
        
        
        
        
        self.f = "l3375P33k"
        
        
        self.g = "5w49"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)