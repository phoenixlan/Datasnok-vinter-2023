
from .Bjarne409 import Bjarne409


class Bjarne1644(Bjarne409):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "1337"
        
        
        self.c = "xbg"
        
        
        
        self.e = "l3375P33k"
        
        
        
        self.g = "5w4G4d3Ll1c"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)