
from .Bjarne114 import Bjarne114


class Bjarne457(Bjarne114):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "5w4G4d3Ll1c"
        
        
        self.d = "k3wL_83An5"
        
        
        self.e = "p3kop3ko"
        
        
        self.f = "p3kop3ko"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)