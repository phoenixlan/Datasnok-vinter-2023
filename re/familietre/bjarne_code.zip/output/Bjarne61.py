

class Bjarne61:
    def __init__(self):
        

        
        self.a = "5w4G4d3Ll1c"
        
        
        self.b = "c00l5sh"
        
        
        self.c = "c00l5sh"
        
        
        self.d = "c00l5sh"
        
        
        self.e = "IrhAh"
        
        
        self.f = "xbg"
        
        
        self.g = "k3wL_83An5"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)