
from .Bjarne1337 import Bjarne1337


class Bjarne1350(Bjarne1337):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "p3kop3ko"
        
        
        self.c = "xbg"
        
        
        
        self.e = "c00l5sh"
        
        
        self.f = "5w4G4d3Ll1c"
        
        
        self.g = "k3wL_83An5"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)