
from .Bjarne389 import Bjarne389


class Bjarne567(Bjarne389):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "xbg"
        
        
        self.c = "c00l5sh"
        
        
        
        self.e = "xbg"
        
        
        self.f = "p3kop3ko"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)