
from .Bjarne204 import Bjarne204


class Bjarne1553(Bjarne204):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "Pho3N1X"
        
        
        
        
        self.d = "k3wL_83An5"
        
        
        self.e = "p3kop3ko"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)