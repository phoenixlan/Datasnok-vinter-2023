
from .Bjarne748 import Bjarne748


class Bjarne1814(Bjarne748):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "l3375P33k"
        
        
        
        self.c = "5w4G4d3Ll1c"
        
        
        self.d = "xbg"
        
        
        self.e = "p3kop3ko"
        
        
        self.f = "5w49"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)