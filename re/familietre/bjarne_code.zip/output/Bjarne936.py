
from .Bjarne381 import Bjarne381


class Bjarne936(Bjarne381):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        self.c = "p3kop3ko"
        
        
        self.d = "p3kop3ko"
        
        
        self.e = "xbg"
        
        
        self.f = "xbg"
        
        
        self.g = "l3375P33k"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)