
from .Bjarne1187 import Bjarne1187


class Bjarne1289(Bjarne1187):
    def __init__(self):
        

        
        
        self.b = "xR4Y"
        
        
        
        self.d = "c00l5sh"
        
        
        self.e = "Pho3N1X"
        
        
        self.f = "k3wL_83An5"
        
        
        self.g = "xR4Y"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)