
from .Bjarne1157 import Bjarne1157


class Bjarne1491(Bjarne1157):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "1337"
        
        
        
        self.c = "xbg"
        
        
        
        self.e = "IrhAh"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)