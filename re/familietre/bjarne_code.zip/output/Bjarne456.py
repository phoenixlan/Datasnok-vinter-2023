
from .Bjarne255 import Bjarne255


class Bjarne456(Bjarne255):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w49"
        
        
        self.b = "Pho3N1X"
        
        
        self.c = "p3kop3ko"
        
        
        self.d = "c00l5sh"
        
        
        self.e = "5w49"
        
        
        self.f = "5w4G4d3Ll1c"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)