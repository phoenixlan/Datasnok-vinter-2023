
from .Bjarne195 import Bjarne195


class Bjarne1895(Bjarne195):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xbg"
        
        
        
        
        self.d = "c00l5sh"
        
        
        self.e = "l3375P33k"
        
        
        self.f = "p3kop3ko"
        
        
        self.g = "xR4Y"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)