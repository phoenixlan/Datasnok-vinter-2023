
from .Bjarne32 import Bjarne32


class Bjarne129(Bjarne32):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "p3kop3ko"
        
        
        self.b = "p3kop3ko"
        
        
        self.c = "xbg"
        
        
        self.d = "5w49"
        
        
        self.e = "IrhAh"
        
        
        self.f = "xbg"
        
        
        self.g = "p3kop3ko"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)