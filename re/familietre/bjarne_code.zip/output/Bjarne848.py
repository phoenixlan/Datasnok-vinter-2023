
from .Bjarne221 import Bjarne221


class Bjarne848(Bjarne221):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "p3kop3ko"
        
        
        self.b = "1337"
        
        
        
        self.d = "5w4G4d3Ll1c"
        
        
        self.e = "Pho3N1X"
        
        
        self.f = "1337"
        
        
        self.g = "8jaRn3"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)