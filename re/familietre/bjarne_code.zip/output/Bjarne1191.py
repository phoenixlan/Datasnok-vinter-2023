
from .Bjarne193 import Bjarne193


class Bjarne1191(Bjarne193):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w49"
        
        
        self.b = "5w4G4d3Ll1c"
        
        
        self.c = "5w49"
        
        
        self.d = "5w49"
        
        
        self.e = "xR4Y"
        
        
        self.f = "IrhAh"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)