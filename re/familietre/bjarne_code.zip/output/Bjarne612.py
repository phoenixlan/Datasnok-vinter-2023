
from .Bjarne530 import Bjarne530


class Bjarne612(Bjarne530):
    def __init__(self):
        
        super().__init__()
        

        
        
        
        
        self.d = "8jaRn3"
        
        
        self.e = "xR4Y"
        
        
        self.f = "c00l5sh"
        
        
        self.g = "Pho3N1X"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)