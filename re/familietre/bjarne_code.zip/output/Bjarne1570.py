
from .Bjarne590 import Bjarne590


class Bjarne1570(Bjarne590):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "c00l5sh"
        
        
        self.b = "IrhAh"
        
        
        self.c = "c00l5sh"
        
        
        
        
        self.f = "k3wL_83An5"
        
        
        self.g = "p3kop3ko"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)