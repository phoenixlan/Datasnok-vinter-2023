
from .Bjarne366 import Bjarne366


class Bjarne1007(Bjarne366):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "xR4Y"
        
        
        self.b = "p3kop3ko"
        
        
        
        self.d = "5w4G4d3Ll1c"
        
        
        self.e = "Pho3N1X"
        
        
        self.f = "1337"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)