
from .Bjarne505 import Bjarne505


class Bjarne1562(Bjarne505):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "1337"
        
        
        self.b = "Pho3N1X"
        
        
        self.c = "Pho3N1X"
        
        
        self.d = "xR4Y"
        
        
        self.e = "k3wL_83An5"
        
        
        self.f = "Pho3N1X"
        
        
        self.g = "IrhAh"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)