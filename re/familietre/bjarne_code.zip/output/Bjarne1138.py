
from .Bjarne798 import Bjarne798


class Bjarne1138(Bjarne798):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "c00l5sh"
        
        
        self.b = "5w4G4d3Ll1c"
        
        
        self.c = "xbg"
        
        
        self.d = "k3wL_83An5"
        
        
        self.e = "xbg"
        
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)