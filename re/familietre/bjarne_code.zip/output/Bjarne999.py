
from .Bjarne223 import Bjarne223


class Bjarne999(Bjarne223):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "p3kop3ko"
        
        
        self.b = "p3kop3ko"
        
        
        self.c = "8jaRn3"
        
        
        self.d = "5w49"
        
        
        
        self.f = "k3wL_83An5"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)