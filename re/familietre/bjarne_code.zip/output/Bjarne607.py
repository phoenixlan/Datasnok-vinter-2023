
from .Bjarne39 import Bjarne39


class Bjarne607(Bjarne39):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "l3375P33k"
        
        
        
        
        self.e = "k3wL_83An5"
        
        
        
        self.g = "k3wL_83An5"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)