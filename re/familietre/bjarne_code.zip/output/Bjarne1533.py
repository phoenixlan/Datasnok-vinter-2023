
from .Bjarne859 import Bjarne859


class Bjarne1533(Bjarne859):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "k3wL_83An5"
        
        
        
        
        
        self.e = "Pho3N1X"
        
        
        self.f = "p3kop3ko"
        
        
        self.g = "8jaRn3"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)