
from .Bjarne728 import Bjarne728


class Bjarne1897(Bjarne728):
    def __init__(self):
        
        super().__init__()
        

        
        
        self.b = "p3kop3ko"
        
        
        
        self.d = "Pho3N1X"
        
        
        
        self.f = "l3375P33k"
        
        
        self.g = "5w49"
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)