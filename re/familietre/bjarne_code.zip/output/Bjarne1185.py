
from .Bjarne89 import Bjarne89


class Bjarne1185(Bjarne89):
    def __init__(self):
        
        super().__init__()
        

        
        self.a = "5w4G4d3Ll1c"
        
        
        self.b = "5w4G4d3Ll1c"
        
        
        
        
        self.e = "8jaRn3"
        
        
        self.f = "xR4Y"
        
        
    
    def get_password(self):
        return "%s.%s.%s.%s.%s.%s" % (self.a, self.b, self.c, self.g, self.e, self.f)